using Newtonsoft.Json;

namespace Echarts
{
	/// <summary>
	/// 自定义系列
	/// 自定义系列可以自定义系列中的图形元素渲染。从而能扩展出不同的图表。
	/// 同时，echarts 会统一管理图形的创建删除、动画、与其他组件（如 dataZoom、visualMap）的联动，使开发者不必纠结这些细节。
	/// 例如，下面的例子使用 custom series 扩展出了 x-range 图：
	/// 
	/// 
	/// 
	/// 更多的例子参见：custom examples
	/// 这里是个教程
	/// 开发者自定义渲染逻辑（renderItem 函数）
	/// custom 系列需要开发者自己提供图形渲染的逻辑。这个渲染逻辑一般命名为 renderItem。例如：
	/// var option = {
	///     ...,
	///     series: [{
	///         type: 'custom',
	///         renderItem: function (params, api) {
	///             var categoryIndex = api.value(0);
	///             var start = api.coord([api.value(1), categoryIndex]);
	///             var end = api.coord([api.value(2), categoryIndex]);
	///             var height = api.size([0, 1])[1] * 0.6;
	/// 
	///             var rectShape = echarts.graphic.clipRectByRect({
	///                 x: start[0],
	///                 y: start[1] - height / 2,
	///                 width: end[0] - start[0],
	///                 height: height
	///             }, {
	///                 x: params.coordSys.x,
	///                 y: params.coordSys.y,
	///                 width: params.coordSys.width,
	///                 height: params.coordSys.height
	///             });
	/// 
	///             return rectShape && {
	///                 type: 'rect',
	///                 shape: rectShape,
	///                 style: api.style()
	///             };
	///         },
	///         data: data
	///     }]
	/// }
	/// 
	/// 对于 data 中的每个数据项（为方便描述，这里称为 dataItem)，会调用此 renderItem 函数。
	/// renderItem 函数提供了两个参数：
	/// 
	/// params：包含了当前数据信息和坐标系的信息。
	/// api：是一些开发者可调用的方法集合。
	/// 
	/// renderItem 函数须返回根据此 dataItem 绘制出的图形元素的定义信息，参见 renderItem.return。
	/// 一般来说，renderItem 函数的主要逻辑，是将 dataItem 里的值映射到坐标系上的图形元素。这一般需要用到 renderItem.arguments.api 中的两个函数：
	/// 
	/// api.value(...)，意思是取出 dataItem 中的数值。例如 api.value(0) 表示取出当前 dataItem 中第一个维度的数值。
	/// api.coord(...)，意思是进行坐标转换计算。例如 var point = api.coord([api.value(0), api.value(1)]) 表示 dataItem 中的数值转换成坐标系上的点。
	/// 
	/// 有时候还需要用到 api.size(...) 函数，表示得到坐标系上一段数值范围对应的长度。
	/// 返回值中样式的设置可以使用 api.style(...) 函数，他能得到 series.itemStyle 中定义的样式信息，以及视觉映射的样式信息。也可以用这种方式覆盖这些样式信息：api.style({fill: 'green', stroke: 'yellow'})。
	/// 维度的映射（encode 和 dimensions 属性）
	/// custom 系列往往需要定义 series.encode，主要用于指明 data 的哪些维度映射到哪些数轴上。从而，echarts 能根据这些维度的值的范围，画出合适的数轴刻度。
	/// 同时，encode.tooltip 和 encode.label 也可以被指定，指明默认的 tooltip 和 label 显示什么内容。series.dimensions 也可以被指定，指明显示在 tooltip 中的维度名称，或者维度的类型。
	/// 例如：
	/// series: {
	///     type: 'custom',
	///     renderItem: function () {
	///         ...
	///     },
	///     encode: {
	///         x: [2, 4, 3],
	///         y: 1,
	///         label: 0,
	///         tooltip: [2, 4, 3]
	///     }
	/// }
	/// 
	/// 与 dataZoom 组件的结合
	/// 与 dataZoom 结合使用的时候，常常使用会设置 dataZoom.filterMode 为 'weakFilter'，从而让 dataItem 部分超出坐标系边界的时候，不会整体被过滤掉。
	/// 关于 dataIndex 和 dataIndexInside 的区别
	/// 
	/// dataIndex 指的 dataItem 在原始数据中的 index。
	/// dataIndexInside 指的是 dataItem 在当前数据窗口（参见 dataZoom）中的 index。
	/// 
	/// renderItem.arguments.api 中使用的参数都是 dataIndexInside 而非 dataIndex，因为从 dataIndex 转换成 dataIndexInside 需要时间开销。
	/// Event listener
	/// chart.setOption({
	///     // ...
	///     series: {
	///         type: 'custom',
	///         renderItem: function () {
	///             // ...
	///             return {
	///                 type: 'group',
	///                 children: [{
	///                     type: 'circle'
	///                     // ...
	///                 }, {
	///                     type: 'circle',
	///                     name: 'aaa',
	///                     // 用户指定的信息，可以在 event handler 访问到。
	///                     info: 12345,
	///                     // ...
	///                 }]
	///             };
	///         }
	///     }
	/// });
	/// chart.on('click', {element: 'aaa'}, function (params) {
	///     // 当 name 为 'aaa' 的图形元素被点击时，此回调被触发。
	///     console.log(params.info);
	/// });
	/// </summary>
	public class SeriesCustom
	{
		/// <summary>
		/// type
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; } = "custom";

		/// <summary>
		/// 组件 ID。默认不指定。指定则可用于在 option 或者 API 中引用组件。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 系列名称，用于tooltip的显示，legend 的图例筛选，在 setOption 更新数据和配置项时用于指定对应的系列。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 从 v5.2.0 开始支持
		/// 
		/// 从调色盘 option.color 中取色的策略，可取值为：
		/// 
		/// 'series'：按照系列分配调色盘中的颜色，同一系列中的所有数据都是用相同的颜色；
		/// 'data'：按照数据项分配调色盘中的颜色，每个数据项都使用不同的颜色。
		/// </summary>
		[JsonProperty("colorBy")]
		public string ColorBy { get; set; }

		/// <summary>
		/// 是否启用图例 hover 时的联动高亮。
		/// </summary>
		[JsonProperty("legendHoverLink")]
		public bool? LegendHoverLink { get; set; }

		/// <summary>
		/// 该系列使用的坐标系，可选：
		/// 
		/// null 或者 'none'
		///   无坐标系。
		/// 
		/// 
		/// 
		/// 'cartesian2d'
		///   使用二维的直角坐标系（也称笛卡尔坐标系），通过 xAxisIndex, yAxisIndex指定相应的坐标轴组件。
		/// 
		/// 
		/// 
		/// 'polar'
		///   使用极坐标系，通过 polarIndex 指定相应的极坐标组件
		/// 
		/// 
		/// 
		/// 'geo'
		///   使用地理坐标系，通过 geoIndex 指定相应的地理坐标系组件。
		/// 
		/// 
		/// 
		/// 'calendar'
		///   使用日历坐标系，通过 calendarIndex 指定相应的日历坐标系组件。
		/// 
		/// 
		/// 
		/// 'none'
		///   不使用坐标系。
		/// </summary>
		[JsonProperty("coordinateSystem")]
		public string CoordinateSystem { get; set; }

		/// <summary>
		/// 使用的 x 轴的 index，在单个图表实例中存在多个 x 轴的时候有用。
		/// </summary>
		[JsonProperty("xAxisIndex")]
		public double? XAxisIndex { get; set; }

		/// <summary>
		/// 使用的 y 轴的 index，在单个图表实例中存在多个 y轴的时候有用。
		/// </summary>
		[JsonProperty("yAxisIndex")]
		public double? YAxisIndex { get; set; }

		/// <summary>
		/// 使用的极坐标系的 index，在单个图表实例中存在多个极坐标系的时候有用。
		/// </summary>
		[JsonProperty("polarIndex")]
		public double? PolarIndex { get; set; }

		/// <summary>
		/// 使用的地理坐标系的 index，在单个图表实例中存在多个地理坐标系的时候有用。
		/// </summary>
		[JsonProperty("geoIndex")]
		public double? GeoIndex { get; set; }

		/// <summary>
		/// 使用的日历坐标系的 index，在单个图表实例中存在多个日历坐标系的时候有用。
		/// </summary>
		[JsonProperty("calendarIndex")]
		public double? CalendarIndex { get; set; }

		/// <summary>
		/// custom 系列需要开发者自己提供图形渲染的逻辑。这个渲染逻辑一般命名为 renderItem。例如：
		/// var option = {
		///     ...,
		///     series: [{
		///         type: 'custom',
		///         renderItem: function (params, api) {
		///             var categoryIndex = api.value(0);
		///             var start = api.coord([api.value(1), categoryIndex]);
		///             var end = api.coord([api.value(2), categoryIndex]);
		///             var height = api.size([0, 1])[1] * 0.6;
		/// 
		///             var rectShape = echarts.graphic.clipRectByRect({
		///                 x: start[0],
		///                 y: start[1] - height / 2,
		///                 width: end[0] - start[0],
		///                 height: height
		///             }, {
		///                 x: params.coordSys.x,
		///                 y: params.coordSys.y,
		///                 width: params.coordSys.width,
		///                 height: params.coordSys.height
		///             });
		/// 
		///             return rectShape && {
		///                 type: 'rect',
		///                 shape: rectShape,
		///                 style: api.style()
		///             };
		///         },
		///         data: data
		///     }]
		/// }
		/// 
		/// 对于 data 中的每个数据项（为方便描述，这里称为 dataItem)，会调用此 renderItem 函数。
		/// renderItem 函数提供了两个参数：
		/// 
		/// params：包含了当前数据信息和坐标系的信息。
		/// api：是一些开发者可调用的方法集合。
		/// 
		/// renderItem 函数须返回根据此 dataItem 绘制出的图形元素的定义信息，参见 renderItem.return。
		/// 一般来说，renderItem 函数的主要逻辑，是将 dataItem 里的值映射到坐标系上的图形元素。这一般需要用到 renderItem.arguments.api 中的两个函数：
		/// 
		/// api.value(...)，意思是取出 dataItem 中的数值。例如 api.value(0) 表示取出当前 dataItem 中第一个维度的数值。
		/// api.coord(...)，意思是进行坐标转换计算。例如 var point = api.coord([api.value(0), api.value(1)]) 表示 dataItem 中的数值转换成坐标系上的点。
		/// 
		/// 有时候还需要用到 api.size(...) 函数，表示得到坐标系上一段数值范围对应的长度。
		/// 返回值中样式的设置可以使用 api.style(...) 函数，他能得到 series.itemStyle 中定义的样式信息，以及视觉映射的样式信息。也可以用这种方式覆盖这些样式信息：api.style({fill: 'green', stroke: 'yellow'})。
		/// </summary>
		[JsonProperty("renderItem")]
		public SeriesCustomRenderItem RenderItem { get; set; }

		/// <summary>
		/// 图形样式。
		/// </summary>
		[JsonProperty("itemStyle")]
		public SeriesCustomItemStyle ItemStyle { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 标签的视觉引导线配置。
		/// </summary>
		[JsonProperty("labelLine")]
		public SeriesCustomLabelLine LabelLine { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 标签的统一布局配置。
		/// 该配置项是在每个系列默认的标签布局基础上，统一调整标签的(x, y)位置，标签对齐等属性以实现想要的标签布局效果。
		/// 该配置项也可以是一个有如下参数的回调函数
		/// // 标签对应数据的 dataIndex
		/// dataIndex: number
		/// // 标签对应的数据类型，只在关系图中会有 node 和 edge 数据类型的区分
		/// dataType?: string
		/// // 标签对应的系列的 index
		/// seriesIndex: number
		/// // 标签显示的文本
		/// text: string
		/// // 默认的标签的包围盒，由系列默认的标签布局决定
		/// labelRect: {x: number, y: number, width: number, height: number}
		/// // 默认的标签水平对齐
		/// align: 'left' | 'center' | 'right'
		/// // 默认的标签垂直对齐
		/// verticalAlign: 'top' | 'middle' | 'bottom'
		/// // 标签所对应的数据图形的包围盒，可用于定位标签位置
		/// rect: {x: number, y: number, width: number, height: number}
		/// // 默认引导线的位置，目前只有饼图(pie)和漏斗图(funnel)有默认标签位置
		/// // 如果没有该值则为 null
		/// labelLinePoints?: number[][]
		/// 
		/// 示例：
		/// 将标签显示在图形右侧 10px 的位置，并且垂直居中：
		/// labelLayout(params) {
		///     return {
		///         x: params.rect.x + 10,
		///         y: params.rect.y + params.rect.height / 2,
		///         verticalAlign: 'middle',
		///         align: 'left'
		///     }
		/// }
		/// 
		/// 根据图形的包围盒尺寸决定文本尺寸
		/// 
		/// labelLayout(params) {
		///     return {
		///         fontSize: Math.max(params.rect.width / 10, 5)
		///     };
		/// }
		/// </summary>
		[JsonProperty("labelLayout")]
		public SeriesCustomLabelLayout LabelLayout { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 选中模式的配置，表示是否支持多个选中，默认关闭，支持布尔值和字符串，字符串取值可选'single'，'multiple'，'series' 分别表示单选，多选以及选择整个系列。
		/// 
		/// 从 v5.3.0 开始支持 'series'。
		/// </summary>
		[JsonProperty("selectedMode")]
		public string SelectedMode { get; set; }

		/// <summary>
		/// 使用 dimensions 定义 series.data 或者 dataset.source 的每个维度的信息。
		/// 注意：如果使用了 dataset，那么可以在 dataset.dimensions 中定义 dimension ，或者在 dataset.source 的第一行/列中给出 dimension 名称。于是就不用在这里指定 dimension。但如果在这里指定了 dimensions，那么优先使用这里的。
		/// 例如：
		/// option = {
		///     dataset: {
		///         source: [
		///             // 有了上面 dimensions 定义后，下面这五个维度的名称分别为：
		///             // 'date', 'open', 'close', 'highest', 'lowest'
		///             [12, 44, 55, 66, 2],
		///             [23, 6, 16, 23, 1],
		///             ...
		///         ]
		///     },
		///     series: {
		///         type: 'xxx',
		///         // 定义了每个维度的名称。这个名称会被显示到默认的 tooltip 中。
		///         dimensions: ['date', 'open', 'close', 'highest', 'lowest']
		///     }
		/// }
		/// 
		/// series: {
		///     type: 'xxx',
		///     dimensions: [
		///         null,                // 如果此维度不想给出定义，则使用 null 即可
		///         {type: 'ordinal'},   // 只定义此维度的类型。
		///                              // 'ordinal' 表示离散型，一般文本使用这种类型。
		///                              // 如果类型没有被定义，会自动猜测类型。
		///         {name: 'good', type: 'number'},
		///         'bad'                // 等同于 {name: 'bad'}
		///     ]
		/// }
		/// 
		/// dimensions 数组中的每一项可以是：
		/// 
		/// string，如 'someName'，等同于 {name: 'someName'}
		/// Object，属性可以有：
		/// name: string。
		/// type: string，支持
		/// number，默认，表示普通数据。
		/// ordinal，对于类目、文本这些 string 类型的数据，如果需要能在数轴上使用，须是 'ordinal' 类型。ECharts 默认会自动判断这个类型。但是自动判断也是不可能很完备的，所以使用者也可以手动强制指定。
		/// float，即 Float64Array。
		/// int，即 Int32Array。
		/// time，表示时间类型。设置成 'time' 则能支持自动解析数据成时间戳（timestamp），比如该维度的数据是 '2017-05-10'，会自动被解析。时间类型的支持参见 data。
		/// 
		/// 
		/// displayName: 一般用于 tooltip 中维度名的展示。string 如果没有指定，默认使用 name 来展示。
		/// 
		/// 
		/// 
		/// 值得一提的是，当定义了 dimensions 后，默认 tooltip 中对个维度的显示，会变为『竖排』，从而方便显示每个维度的名称。如果没有定义 dimensions，则默认 tooltip 会横排显示，且只显示数值没有维度名称可显示。
		/// </summary>
		[JsonProperty("dimensions")]
		public double[] Dimensions { get; set; }

		/// <summary>
		/// 可以定义 data 的哪个维度被编码成什么。比如：
		/// option = {
		///     dataset: {
		///         source: [
		///             // 每一列称为一个『维度』。
		///             // 这里分别是维度 0、1、2、3、4。
		///             [12, 44, 55, 66, 2],
		///             [23, 6, 16, 23, 1],
		///             ...
		///         ]
		///     },
		///     series: {
		///         type: 'xxx',
		///         encode: {
		///             x: [3, 1, 5],      // 表示维度 3、1、5 映射到 x 轴。
		///             y: 2,              // 表示维度 2 映射到 y 轴。
		///             tooltip: [3, 2, 4] // 表示维度 3、2、4 会在 tooltip 中显示。
		///         }
		///     }
		/// }
		/// 
		/// 当使用 dimensions 给维度定义名称后，encode 中可直接引用名称，例如：
		/// series: {
		///     type: 'xxx',
		///     dimensions: ['date', 'open', 'close', 'highest', 'lowest'],
		///     encode: {
		///         x: 'date',
		///         y: ['open', 'close', 'highest', 'lowest']
		///     }
		/// }
		/// 
		/// encode 声明的基本结构如下，其中冒号左边是坐标系、标签等特定名称，如 'x', 'y', 'tooltip' 等，冒号右边是数据中的维度名（string 格式）或者维度的序号（number 格式，从 0 开始计数），可以指定一个或多个维度（使用数组）。通常情况下，下面各种信息不需要所有的都写，按需写即可。
		/// 下面是 encode 支持的属性：
		/// // 在任何坐标系和系列中，都支持：
		/// encode: {
		///     // 使用 “名为 product 的维度” 和 “名为 score 的维度” 的值在 tooltip 中显示
		///     tooltip: ['product', 'score']
		///     // 使用第一个维度和第三个维度的维度名连起来作为系列名。（有时候名字比较长，这可以避免在 series.name 重复输入这些名字）
		///     seriesName: [1, 3],
		///     // 表示使用第二个维度中的值作为 id。这在使用 setOption 动态更新数据时有用处，可以使新老数据用 id 对应起来，从而能够产生合适的数据更新动画。
		///     itemId: 2,
		///     // 指定数据项的名称使用第三个维度在饼图等图表中有用，可以使这个名字显示在图例（legend）中。
		///     itemName: 3,
		///     // 指定数据项的组 ID (groupId)。当全局过渡动画功能开启时，setOption 前后拥有相同 groupId 的数据项会进行动画过渡。
		///     itemGroupId: 4,
		///     // 指定数据项对应的子数据组 ID (childGroupId)，用于实现多层下钻和聚合。详见 childGroupId。
		///     // 从 v5.5.0 开始支持
		///     itemChildGroupId: 5
		/// }
		/// 
		/// // 直角坐标系（grid/cartesian）特有的属性：
		/// encode: {
		///     // 把 “维度1”、“维度5”、“名为 score 的维度” 映射到 X 轴：
		///     x: [1, 5, 'score'],
		///     // 把“维度0”映射到 Y 轴。
		///     y: 0
		/// }
		/// 
		/// // 单轴（singleAxis）特有的属性：
		/// encode: {
		///     single: 3
		/// }
		/// 
		/// // 极坐标系（polar）特有的属性：
		/// encode: {
		///     radius: 3,
		///     angle: 2
		/// }
		/// 
		/// // 地理坐标系（geo）特有的属性：
		/// encode: {
		///     lng: 3,
		///     lat: 2
		/// }
		/// 
		/// // 对于一些没有坐标系的图表，例如饼图、漏斗图等，可以是：
		/// encode: {
		///     value: 3
		/// }
		/// 
		/// 这是个更丰富的 encode 的示例：
		/// 特殊地，在 自定义系列（custom series） 中，encode 中轴可以不指定或设置为 null/undefined，从而使系列免于受这个轴控制，也就是说，轴的范围（extent）不会受此系列数值的影响，轴被 dataZoom 控制时也不会过滤掉这个系列：
		/// var option = {
		///     xAxis: {},
		///     yAxis: {},
		///     dataZoom: [{
		///         xAxisIndex: 0
		///     }, {
		///         yAxisIndex: 0
		///     }],
		///     series: {
		///         type: 'custom',
		///         renderItem: function (params, api) {
		///             return {
		///                 type: 'circle',
		///                 shape: {
		///                     cx: 100, // x 位置永远为 100
		///                     cy: api.coord([0, api.value(0)])[1],
		///                     r: 30
		///                 },
		///                 style: {
		///                     fill: 'blue'
		///                 }
		///             };
		///         },
		///         encode: {
		///             // 这样这个系列就不会被 x 轴以及 x
		///             // 轴上的 dataZoom 控制了。
		///             x: -1,
		///             y: 1
		///         },
		///         data: [ ... ]
		///     }
		/// };
		/// </summary>
		[JsonProperty("encode")]
		public object Encode { get; set; }

		/// <summary>
		/// 当使用 dataset 时，seriesLayoutBy 指定了 dataset 中用行还是列对应到系列上，也就是说，系列“排布”到 dataset 的行还是列上。可取值：
		/// 
		/// 'column'：默认，dataset 的列对应于系列，从而 dataset 中每一列是一个维度（dimension）。
		/// 'row'：dataset 的行对应于系列，从而 dataset 中每一行是一个维度（dimension）。
		/// 
		/// 参见这个 示例
		/// </summary>
		[JsonProperty("seriesLayoutBy")]
		public string SeriesLayoutBy { get; set; }

		/// <summary>
		/// 如果 series.data 没有指定，并且 dataset 存在，那么就会使用 dataset。datasetIndex 指定本系列使用哪个 dataset。
		/// </summary>
		[JsonProperty("datasetIndex")]
		public double? DatasetIndex { get; set; }

		/// <summary>
		/// 该系列所有数据项的组 ID，优先级低于groupId。详见series.data.groupId。
		/// </summary>
		[JsonProperty("dataGroupId")]
		public string DataGroupId { get; set; }

		/// <summary>
		/// 系列中的数据内容数组。数组项通常为具体的数据项。
		/// 注意，如果系列没有指定 data，并且 option 有 dataset，那么默认使用第一个 dataset。如果指定了 data，则不会再使用 dataset。
		/// 可以使用 series.datasetIndex 指定其他的 dataset。
		/// 通常来说，数据用一个二维数组表示。如下，每一列被称为一个『维度』。
		/// series: [{
		///     data: [
		///         // 维度X   维度Y   其他维度 ...
		///         [  3.4,    4.5,   15,   43],
		///         [  4.2,    2.3,   20,   91],
		///         [  10.8,   9.5,   30,   18],
		///         [  7.2,    8.8,   18,   57]
		///     ]
		/// }]
		/// 
		/// 
		/// 在 直角坐标系 (grid) 中『维度X』和『维度Y』会默认对应于 xAxis 和 yAxis。
		/// 在 极坐标系 (polar) 中『维度X』和『维度Y』会默认对应于 radiusAxis 和 angleAxis。
		/// 后面的其他维度是可选的，可以在别处被使用，例如：
		/// 在 visualMap 中可以将一个或多个维度映射到颜色，大小等多个图形属性上。
		/// 在 series.symbolSize 中可以使用回调函数，基于某个维度得到 symbolSize 值。
		/// 使用 tooltip.formatter 或 series.label.formatter 可以把其他维度的值展示出来。
		/// 
		/// 
		/// 
		/// 特别地，当只有一个轴为类目轴（axis.type 为 'category'）的时候，数据可以简化用一个一维数组表示。例如：
		/// xAxis: {
		///     data: ['a', 'b', 'm', 'n']
		/// },
		/// series: [{
		///     // 与 xAxis.data 一一对应。
		///     data: [23,  44,  55,  19]
		///     // 它其实是下面这种形式的简化：
		///     // data: [[0, 23], [1, 44], [2, 55], [3, 19]]
		/// }]
		/// 
		/// 『值』与 轴类型 的关系：
		/// 
		/// 当某维度对应于数值轴（axis.type 为 'value' 或者 'log'）的时候：
		///   其值可以为 number（例如 12）。（也可以兼容 string 形式的 number，例如 '12'）
		/// 
		/// 当某维度对应于类目轴（axis.type 为 'category'）的时候：
		///   其值须为类目的『序数』（从 0 开始）或者类目的『字符串值』。例如：
		///   xAxis: {
		///       type: 'category',
		///       data: ['星期一', '星期二', '星期三', '星期四']
		///   },
		///   yAxis: {
		///       type: 'category',
		///       data: ['a', 'b', 'm', 'n', 'p', 'q']
		///   },
		///   series: [{
		///       data: [
		///           // xAxis    yAxis
		///           [  0,        0,    2  ], // 意思是此点位于 xAxis: '星期一', yAxis: 'a'。
		///           [  '星期四',  2,    1  ], // 意思是此点位于 xAxis: '星期四', yAxis: 'm'。
		///           [  2,       'p',   2  ], // 意思是此点位于 xAxis: '星期三', yAxis: 'p'。
		///           [  3,        3,    5  ]
		///       ]
		///   }]
		/// 
		///   双类目轴的示例可以参考 Github Punchcard 示例。
		/// 
		/// 当某维度对应于时间轴（type 为 'time'）的时候，值可以为：
		/// 
		/// 一个时间戳，如 1484141700832，表示 UTC 时间。
		/// 或者字符串形式的时间描述：
		/// ISO 8601 的子集，只包含这些形式（这几种格式，除非指明时区，否则均表示本地时间，与 moment 一致）：
		/// 部分年月日时间: '2012-03', '2012-03-01', '2012-03-01 05', '2012-03-01 05:06'.
		/// 使用 'T' 或空格分割: '2012-03-01T12:22:33.123', '2012-03-01 12:22:33.123'.
		/// 时区设定: '2012-03-01T12:22:33Z', '2012-03-01T12:22:33+8000', '2012-03-01T12:22:33-05:00'.
		/// 
		/// 
		/// 其他的时间字符串，包括（均表示本地时间）:
		/// '2012', '2012-3-1', '2012/3/1', '2012/03/01',
		/// '2009/6/12 2:00', '2009/6/12 2:05:08', '2009/6/12 2:05:08.123'
		/// 
		/// 
		/// 或者用户自行初始化的 Date 实例：
		/// 注意，用户自行初始化 Date 实例的时候，浏览器的行为有差异，不同字符串的表示也不同。
		/// 例如：在 chrome 中，new Date('2012-01-01') 表示 UTC 时间的 2012 年 1 月 1 日，而 new Date('2012-1-1') 和 new Date('2012/01/01') 表示本地时间的 2012 年 1 月 1 日。在 safari 中，不支持 new Date('2012-1-1') 这种表示方法。
		/// 所以，使用 new Date(dataString) 时，可使用第三方库解析（如 moment），或者使用 echarts.time.parse，或者参见 这里。
		/// 
		/// 
		/// 
		/// 
		/// 
		/// 当需要对个别数据进行个性化定义时：
		/// 数组项可用对象，其中的 value 像表示具体的数值，如：
		/// [
		///     12,
		///     34,
		///     {
		///         value : 56,
		///         //自定义标签样式，仅对该数据项有效
		///         label: {},
		///         //自定义特殊 itemStyle，仅对该数据项有效
		///         itemStyle:{}
		///     },
		///     10
		/// ]
		/// // 或
		/// [
		///     [12, 33],
		///     [34, 313],
		///     {
		///         value: [56, 44],
		///         label: {},
		///         itemStyle:{}
		///     },
		///     [10, 33]
		/// ]
		/// 
		/// 空值：
		/// 当某数据不存在时（ps：不存在不代表值为 0），可以用 '-' 或者 null 或者 undefined 或者 NaN 表示。
		/// 例如，无数据在折线图中可表现为该点是断开的，在其它图中可表示为图形不存在。
		/// </summary>
		[JsonProperty("data")]
		public SeriesCustomData Data { get; set; }

		/// <summary>
		/// 从 v4.4.0 开始支持
		/// 
		/// 是否裁剪超出坐标系部分的图形，具体裁剪效果根据系列决定：
		/// 
		/// 散点图/带有涟漪特效动画的散点（气泡）图：忽略中心点超出坐标系的图形，但是不裁剪单个图形
		/// 柱状图：裁掉完全超出的柱子，但是不会裁剪只超出部分的柱子
		/// 折线图：裁掉所有超出坐标系的折线部分，拐点图形的逻辑按照散点图处理
		/// 路径图：裁掉所有超出坐标系的部分
		/// K 线图：忽略整体都超出坐标系的图形，但是不裁剪单个图形
		/// 象形柱图：裁掉所有超出坐标系的部分（从 v5.5.0 开始支持）
		/// 自定义系列：裁掉所有超出坐标系的部分
		/// 
		/// 除了象形柱图和自定义系列，其它系列的默认值都为 true，及开启裁剪，如果你觉得不想要裁剪的话，可以设置成 false 关闭。
		/// </summary>
		[JsonProperty("clip")]
		public bool? Clip { get; set; }

		/// <summary>
		/// 自定义图所有图形的 zlevel 值。
		/// zlevel用于 Canvas 分层，不同zlevel值的图形会放置在不同的 Canvas 中，Canvas 分层是一种常见的优化手段。我们可以把一些图形变化频繁（例如有动画）的组件设置成一个单独的zlevel。需要注意的是过多的 Canvas 会引起内存开销的增大，在手机端上需要谨慎使用以防崩溃。
		/// zlevel 大的 Canvas 会放在 zlevel 小的 Canvas 的上面。
		/// </summary>
		[JsonProperty("zlevel")]
		public double? Zlevel { get; set; }

		/// <summary>
		/// 自定义图组件的所有图形的z值。控制图形的前后顺序。z值小的图形会被z值大的图形覆盖。
		/// z相比zlevel优先级更低，而且不会创建新的 Canvas。
		/// </summary>
		[JsonProperty("z")]
		public double? Z { get; set; }

		/// <summary>
		/// 图形是否不响应和触发鼠标事件，默认为 false，即响应和触发鼠标事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 是否开启动画。
		/// </summary>
		[JsonProperty("animation")]
		public bool? Animation { get; set; }

		/// <summary>
		/// 是否开启动画的阈值，当单个系列显示的图形数量大于这个阈值时会关闭动画。
		/// </summary>
		[JsonProperty("animationThreshold")]
		public double? AnimationThreshold { get; set; }

		/// <summary>
		/// 初始动画的时长，支持回调函数，可以通过每个数据返回不同的时长实现更戏剧的初始动画效果：
		/// animationDuration: function (idx) {
		///     // 越往后的数据时长越大
		///     return idx * 100;
		/// }
		/// </summary>
		[JsonProperty("animationDuration")]
		public double? AnimationDuration { get; set; }

		/// <summary>
		/// 初始动画的缓动效果。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("animationEasing")]
		public string AnimationEasing { get; set; }

		/// <summary>
		/// 初始动画的延迟，支持回调函数，可以通过每个数据返回不同的 delay 时间实现更戏剧的初始动画效果。
		/// 如下示例：
		/// animationDelay: function (idx) {
		///     // 越往后的数据延迟越大
		///     return idx * 100;
		/// }
		/// 
		/// 也可以看该示例
		/// </summary>
		[JsonProperty("animationDelay")]
		public StringOrNumber AnimationDelay { get; set; }

		/// <summary>
		/// 数据更新动画的时长。
		/// 支持回调函数，可以通过每个数据返回不同的时长实现更戏剧的更新动画效果：
		/// animationDurationUpdate: function (idx) {
		///     // 越往后的数据时长越大
		///     return idx * 100;
		/// }
		/// </summary>
		[JsonProperty("animationDurationUpdate")]
		public double? AnimationDurationUpdate { get; set; }

		/// <summary>
		/// 数据更新动画的缓动效果。
		/// </summary>
		[JsonProperty("animationEasingUpdate")]
		public string AnimationEasingUpdate { get; set; }

		/// <summary>
		/// 数据更新动画的延迟，支持回调函数，可以通过每个数据返回不同的 delay 时间实现更戏剧的更新动画效果。
		/// 如下示例：
		/// animationDelayUpdate: function (idx) {
		///     // 越往后的数据延迟越大
		///     return idx * 100;
		/// }
		/// 
		/// 也可以看该示例
		/// </summary>
		[JsonProperty("animationDelayUpdate")]
		public StringOrNumber AnimationDelayUpdate { get; set; }

		/// <summary>
		/// 从 v5.2.0 开始支持
		/// 
		/// 全局过渡动画相关的配置。
		/// 全局过渡动画（Universal Transition）提供了任意系列之间进行变形动画的功能。开启该功能后，每次setOption，相同id的系列之间会自动关联进行动画的过渡，更细粒度的关联配置见universalTransition.seriesKey配置。
		/// 通过配置数据项的groupId和childGroupId，还可以实现诸如下钻，聚合等一对多或者多对一的动画。
		/// 可以直接在系列中配置 universalTransition: true 开启该功能。也可以提供一个对象进行更多属性的配置。
		/// </summary>
		[JsonProperty("universalTransition")]
		public SeriesCustomUniversalTransition UniversalTransition { get; set; }

		/// <summary>
		/// 本系列特定的 tooltip 设定。
		/// </summary>
		[JsonProperty("tooltip")]
		public SeriesCustomTooltip Tooltip { get; set; }
	}

	public class SeriesCustomTooltip
	{
		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的位置，默认不设置时位置会跟随鼠标的位置。
		/// 可选：
		/// 
		/// Array
		///   通过数组表示提示框浮层的位置，支持数字设置绝对位置，百分比设置相对位置。
		///   示例:
		///   // 绝对位置，相对于容器左侧 10px, 上侧 10 px
		///   position: [10, 10]
		///   // 相对位置，放置在容器正中间
		///   position: ['50%', '50%']
		/// 
		/// 
		/// Function
		///   回调函数，格式如下：
		///   (point: Array, params: Object|Array.<Object>, dom: HTMLDomElement, rect: Object, size: Object) => Array
		/// 
		///   参数：
		///   point: 鼠标位置，如 [20, 40]。
		///   params: 同 formatter 的参数相同。
		///   dom: tooltip 的 dom 对象。
		///   rect: 只有鼠标在图形上时有效，是一个用x, y, width, height四个属性表达的图形包围盒。
		///   size: 包括 dom 的尺寸和 echarts 容器的当前尺寸，例如：{contentSize: [width, height], viewSize: [width, height]}。
		///   返回值：
		///   可以是一个表示 tooltip 位置的数组，数组值可以是绝对的像素值，也可以是相  百分比。
		///   也可以是一个对象，如：{left: 10, top: 30}，或者 {right: '20%', bottom: 40}。
		///   如下示例：
		///   position: function (point, params, dom, rect, size) {
		///       // 固定在顶部
		///       return [point[0], '10%'];
		///   }
		/// 
		///   或者：
		///   position: function (pos, params, dom, rect, size) {
		///       // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
		///       var obj = {top: 60};
		///       obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5;
		///       return obj;
		///   }
		/// 
		/// 
		/// 
		/// 
		/// 'inside'
		///   鼠标所在图形的内部中心位置，只在 trigger 为'item'的时候有效。
		/// 
		/// 'top'
		///   鼠标所在图形上侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'left'
		///   鼠标所在图形左侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'right'
		///   鼠标所在图形右侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'bottom'
		///   鼠标所在图形底侧，只在 trigger 为'item'的时候有效。
		/// </summary>
		[JsonProperty("position")]
		public string[] Position { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层内容格式器，支持字符串模板和回调函数两种形式。
		/// 1. 字符串模板
		/// 模板变量有 {a}, {b}，{c}，{d}，{e}，分别表示系列名，数据名，数据值等。
		/// 在 trigger 为 'axis' 的时候，会有多个系列的数据，此时可以通过 {a0}, {a1}, {a2} 这种后面加索引的方式表示系列的索引。
		/// 不同图表类型下的 {a}，{b}，{c}，{d} 含义不一样。
		/// 其中变量{a}, {b}, {c}, {d}在不同图表类型下代表数据含义为：
		/// 
		/// 折线（区域）图、柱状（条形）图、K线图 : {a}（系列名称），{b}（类目值），{c}（数值）, {d}（无）
		/// 
		/// 散点图（气泡）图 : {a}（系列名称），{b}（数据名称），{c}（数值数组）, {d}（无）
		/// 
		/// 地图 : {a}（系列名称），{b}（区域名称），{c}（合并数值）, {d}（无）
		/// 
		/// 饼图、仪表盘、漏斗图: {a}（系列名称），{b}（数据项名称），{c}（数值）, {d}（百分比）
		/// 
		/// 
		/// 更多其它图表模板变量的含义可以见相应的图表的 label.formatter 配置项。
		/// 示例：
		/// formatter: '{b0}: {c0}<br />{b1}: {c1}'
		/// 
		/// 2. 回调函数
		/// 回调函数格式：
		/// (params: Object|Array, ticket: string, callback: (ticket: string, html: string)) => string | HTMLElement | HTMLElement[]
		/// 
		/// 支持返回 HTML 字符串或者创建的 DOM 实例。
		/// 第一个参数 params 是 formatter 需要的数据集。格式如下：
		/// {
		///     componentType: 'series',
		///     // 系列类型
		///     seriesType: string,
		///     // 系列在传入的 option.series 中的 index
		///     seriesIndex: number,
		///     // 系列名称
		///     seriesName: string,
		///     // 数据名，类目名
		///     name: string,
		///     // 数据在传入的 data 数组中的 index
		///     dataIndex: number,
		///     // 传入的原始数据项
		///     data: Object,
		///     // 传入的数据值。在多数系列下它和 data 相同。在一些系列下是 data 中的分量（如 map、radar 中）
		///     value: number|Array|Object,
		///     // 坐标轴 encode 映射信息，
		///     // key 为坐标轴（如 'x' 'y' 'radius' 'angle' 等）
		///     // value 必然为数组，不会为 null/undefined，表示 dimension index 。
		///     // 其内容如：
		///     // {
		///     //     x: [2] // dimension index 为 2 的数据映射到 x 轴
		///     //     y: [0] // dimension index 为 0 的数据映射到 y 轴
		///     // }
		///     encode: Object,
		///     // 维度名列表
		///     dimensionNames: Array<String>,
		///     // 数据的维度 index，如 0 或 1 或 2 ...
		///     // 仅在雷达图中使用。
		///     dimensionIndex: number,
		///     // 数据图形的颜色
		///     color: string,
		///     // 饼图/漏斗图的百分比
		///     percent: number,
		///     // 旭日图中当前节点的祖先节点（包括自身）
		///     treePathInfo: Array,
		///     // 树图/矩形树图中当前节点的祖先节点（包括自身）
		///     treeAncestors: Array
		/// }
		/// 
		/// 注：encode 和 dimensionNames 的使用方式，例如：
		/// 如果数据为：
		/// dataset: {
		///     source: [
		///         ['Matcha Latte', 43.3, 85.8, 93.7],
		///         ['Milk Tea', 83.1, 73.4, 55.1],
		///         ['Cheese Cocoa', 86.4, 65.2, 82.5],
		///         ['Walnut Brownie', 72.4, 53.9, 39.1]
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.encode.y[0]]
		/// 
		/// 如果数据为：
		/// dataset: {
		///     dimensions: ['product', '2015', '2016', '2017'],
		///     source: [
		///         {product: 'Matcha Latte', '2015': 43.3, '2016': 85.8, '2017': 93.7},
		///         {product: 'Milk Tea', '2015': 83.1, '2016': 73.4, '2017': 55.1},
		///         {product: 'Cheese Cocoa', '2015': 86.4, '2016': 65.2, '2017': 82.5},
		///         {product: 'Walnut Brownie', '2015': 72.4, '2016': 53.9, '2017': 39.1}
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.dimensionNames[params.encode.y[0]]]
		/// 
		/// 在 trigger 为 'axis' 的时候，或者 tooltip 被 axisPointer 触发的时候，params 是多个系列的数据数组。其中每项内容格式同上，并且，
		/// {
		///     componentType: 'series',
		///     // 系列类型
		///     seriesType: string,
		///     // 系列在传入的 option.series 中的 index
		///     seriesIndex: number,
		///     // 系列名称
		///     seriesName: string,
		///     // 数据名，类目名
		///     name: string,
		///     // 数据在传入的 data 数组中的 index
		///     dataIndex: number,
		///     // 传入的原始数据项
		///     data: Object,
		///     // 传入的数据值。在多数系列下它和 data 相同。在一些系列下是 data 中的分量（如 map、radar 中）
		///     value: number|Array|Object,
		///     // 坐标轴 encode 映射信息，
		///     // key 为坐标轴（如 'x' 'y' 'radius' 'angle' 等）
		///     // value 必然为数组，不会为 null/undefined，表示 dimension index 。
		///     // 其内容如：
		///     // {
		///     //     x: [2] // dimension index 为 2 的数据映射到 x 轴
		///     //     y: [0] // dimension index 为 0 的数据映射到 y 轴
		///     // }
		///     encode: Object,
		///     // 维度名列表
		///     dimensionNames: Array<String>,
		///     // 数据的维度 index，如 0 或 1 或 2 ...
		///     // 仅在雷达图中使用。
		///     dimensionIndex: number,
		///     // 数据图形的颜色
		///     color: string
		/// }
		/// 
		/// 注：encode 和 dimensionNames 的使用方式，例如：
		/// 如果数据为：
		/// dataset: {
		///     source: [
		///         ['Matcha Latte', 43.3, 85.8, 93.7],
		///         ['Milk Tea', 83.1, 73.4, 55.1],
		///         ['Cheese Cocoa', 86.4, 65.2, 82.5],
		///         ['Walnut Brownie', 72.4, 53.9, 39.1]
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.encode.y[0]]
		/// 
		/// 如果数据为：
		/// dataset: {
		///     dimensions: ['product', '2015', '2016', '2017'],
		///     source: [
		///         {product: 'Matcha Latte', '2015': 43.3, '2016': 85.8, '2017': 93.7},
		///         {product: 'Milk Tea', '2015': 83.1, '2016': 73.4, '2017': 55.1},
		///         {product: 'Cheese Cocoa', '2015': 86.4, '2016': 65.2, '2017': 82.5},
		///         {product: 'Walnut Brownie', '2015': 72.4, '2016': 53.9, '2017': 39.1}
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.dimensionNames[params.encode.y[0]]]
		/// 
		/// 第二个参数 ticket 是异步回调标识，配合第三个参数 callback 使用。
		/// 第三个参数 callback 是异步回调，在提示框浮层内容是异步获取的时候，可以通过 callback 传入上述的 ticket 和 html 更新提示框浮层内容。
		/// 示例：
		/// formatter: function (params, ticket, callback) {
		///     $.get('detail?name=' + params.name, function (content) {
		///         callback(ticket, toHTML(content));
		///     });
		///     return 'Loading';
		/// }
		/// </summary>
		[JsonProperty("formatter")]
		public string Formatter { get; set; }

		/// <summary>
		/// 从 v5.3.0 开始支持
		/// 
		/// tooltip 中数值显示部分的格式化回调函数。
		/// 回调函数格式：
		/// (value: number | string, dataIndex: number) => string
		/// 
		/// 
		/// 自 v5.5.0 版本起提供 dataIndex。
		/// 
		/// 示例：
		/// // 添加 $ 前缀
		/// valueFormatter: (value) => '$' + value.toFixed(2)
		/// </summary>
		[JsonProperty("valueFormatter")]
		public string ValueFormatter { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的背景颜色。
		/// </summary>
		[JsonProperty("backgroundColor")]
		public Color BackgroundColor { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的边框颜色。
		/// </summary>
		[JsonProperty("borderColor")]
		public Color BorderColor { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的边框宽。
		/// </summary>
		[JsonProperty("borderWidth")]
		public double? BorderWidth { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 
		/// 
		/// 提示框浮层内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距。
		/// 使用示例：
		/// // 设置内边距为 5
		/// padding: 5
		/// // 设置上下的内边距为 5，左右的内边距为 10
		/// padding: [5, 10]
		/// // 分别设置四个方向的内边距
		/// padding: [
		///     5,  // 上
		///     10, // 右
		///     5,  // 下
		///     10, // 左
		/// ]
		/// </summary>
		[JsonProperty("padding")]
		public StringOrNumber[] Padding { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的文本样式。
		/// </summary>
		[JsonProperty("textStyle")]
		public SeriesCustomTooltipTextStyle TextStyle { get; set; }

		/// <summary>
		/// 注意：series.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 额外附加到浮层的 css 样式。如下为浮层添加阴影的示例：
		/// extraCssText: 'box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);'
		/// </summary>
		[JsonProperty("extraCssText")]
		public string ExtraCssText { get; set; }
	}

	public class SeriesCustomTooltipTextStyle
	{
		/// <summary>
		/// 文字的颜色。
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 文字字体的风格。
		/// 可选：
		/// 
		/// 'normal'
		/// 'italic'
		/// 'oblique'
		/// </summary>
		[JsonProperty("fontStyle")]
		public string FontStyle { get; set; }

		/// <summary>
		/// 文字字体的粗细。
		/// 可选：
		/// 
		/// 'normal'
		/// 'bold'
		/// 'bolder'
		/// 'lighter'
		/// 100 | 200 | 300 | 400...
		/// </summary>
		[JsonProperty("fontWeight")]
		public string FontWeight { get; set; }

		/// <summary>
		/// 文字的字体系列。
		/// 还可以是 'serif' , 'monospace', 'Arial', 'Courier New', 'Microsoft YaHei', ...
		/// </summary>
		[JsonProperty("fontFamily")]
		public string FontFamily { get; set; }

		/// <summary>
		/// 文字的字体大小。
		/// </summary>
		[JsonProperty("fontSize")]
		public double? FontSize { get; set; }

		/// <summary>
		/// 行高。
		/// rich 中如果没有设置 lineHeight，则会取父层级的 lineHeight。例如：
		/// {
		///     lineHeight: 56,
		///     rich: {
		///         a: {
		///             // 没有设置 `lineHeight`，则 `lineHeight` 为 56
		///         }
		///     }
		/// }
		/// </summary>
		[JsonProperty("lineHeight")]
		public double? LineHeight { get; set; }

		/// <summary>
		/// 文本显示宽度。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 文本显示高度。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 文字本身的描边颜色。
		/// </summary>
		[JsonProperty("textBorderColor")]
		public Color TextBorderColor { get; set; }

		/// <summary>
		/// 文字本身的描边宽度。
		/// </summary>
		[JsonProperty("textBorderWidth")]
		public double? TextBorderWidth { get; set; }

		/// <summary>
		/// 文字本身的描边类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// textBorderDashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// textBorderType: [5, 10],
		/// 
		/// textBorderDashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("textBorderType")]
		public string TextBorderType { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// textBorderType
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("textBorderDashOffset")]
		public double? TextBorderDashOffset { get; set; }

		/// <summary>
		/// 文字本身的阴影颜色。
		/// </summary>
		[JsonProperty("textShadowColor")]
		public Color TextShadowColor { get; set; }

		/// <summary>
		/// 文字本身的阴影长度。
		/// </summary>
		[JsonProperty("textShadowBlur")]
		public double? TextShadowBlur { get; set; }

		/// <summary>
		/// 文字本身的阴影 X 偏移。
		/// </summary>
		[JsonProperty("textShadowOffsetX")]
		public double? TextShadowOffsetX { get; set; }

		/// <summary>
		/// 文字本身的阴影 Y 偏移。
		/// </summary>
		[JsonProperty("textShadowOffsetY")]
		public double? TextShadowOffsetY { get; set; }

		/// <summary>
		/// 文字超出宽度是否截断或者换行。配置width时有效
		/// 
		/// 'truncate' 截断，并在末尾显示ellipsis配置的文本，默认为...
		/// 'break' 换行
		/// 'breakAll' 换行，跟'break'不同的是，在英语等拉丁文中，'breakAll'还会强制单词内换行
		/// </summary>
		[JsonProperty("overflow")]
		public string Overflow { get; set; }

		/// <summary>
		/// 在overflow配置为'truncate'的时候，可以通过该属性配置末尾显示的文本。
		/// </summary>
		[JsonProperty("ellipsis")]
		public string Ellipsis { get; set; }
	}

	public class SeriesCustomUniversalTransition
	{
		/// <summary>
		/// 是否开启全局过渡动画。
		/// </summary>
		[JsonProperty("enabled")]
		public bool? Enabled { get; set; }

		/// <summary>
		/// seriesKey决定了如何关联需要动画的系列，未配置时会默认取系列的id。
		/// 通常该配置为一个字符串，配置为相同seriesKey的系列之间会进行动画的过渡。也可以像下面配置为一个数组：
		/// seriesKey: ['male', 'female']
		/// 
		/// 配置为数组意味着在动画的时候所有数组项指定的系列会合并为当前系列。比如该配置是指id或者seriesKey为'male'和'female'的系列会合并成当前系列。
		/// </summary>
		[JsonProperty("seriesKey")]
		public string[] SeriesKey { get; set; }

		/// <summary>
		/// divideShape决定在一对多或者多对一的动画中，当前系列的图形如何分裂成多个图形。目前支持
		/// 
		/// 'split' 通过一定的算法将分割图形成为多个。
		/// 'clone' 从当前图形克隆得到多个。
		/// 
		/// 为了较好的效果，不同的系列会默认有不同的配置，比如散点图这种图形比较小且复杂的默认采用了'clone'，而柱状图这种更加规则的则默认是'split'。你可以根据你自己的场景需求设置为需要的分裂策略。
		/// </summary>
		[JsonProperty("divideShape")]
		public string DivideShape { get; set; }

		/// <summary>
		/// (index: number, count: number) => number
		/// 
		/// 配置一对多或者多对一的动画中每个图形的动画延时，设置不同的动画延时可以给动画带来一定的趣味性。比如下面代码每个图形通过一个随机的延时造成一种错落的效果：
		/// delay: function (index, count) {
		///     return Math.random() * 1000;
		/// }
		/// </summary>
		[JsonProperty("delay")]
		public string Delay { get; set; }
	}

	public class SeriesCustomData
	{
		/// <summary>
		/// 数据项名称。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 单个数据项的数值。
		/// </summary>
		[JsonProperty("value")]
		public double? Value { get; set; }

		/// <summary>
		/// 该数据项的组 ID。当全局过渡动画功能开启时，setOption 前后拥有相同组 ID 的数据项会进行动画过渡。
		/// 若没有指定groupId ，会尝试用series.dataGroupId作为该数据项的组 ID；若series.dataGroupId也没有指定，则会使用数据项的 ID 作为组 ID。
		/// 如果你使用了dataset组件来表达数据，推荐使用encode.itemGroupId来指定哪个维度被编码为组 ID。
		/// </summary>
		[JsonProperty("groupId")]
		public string GroupId { get; set; }

		/// <summary>
		/// 从 v5.5.0 开始支持
		/// 
		/// 该数据项对应的子数据组 ID，用于实现多层下钻和聚合。
		/// 
		/// 
		/// 
		/// 通过groupId已经可以达到数据下钻和聚合的效果，但只支持一层的下钻和聚合。为了实现多层下钻和聚合，我们又引入了childGroupId。
		/// 引入childGroupId后，不同option的数据项之间就能形成逻辑上的父子关系，例如：
		/// data: [                        data: [                        data: [
		///   {                              {                              {
		///     name: 'Animals',               name: 'Dogs',                  name: 'Corgi',
		///     value: 3,                      value: 3,                      value: 5,
		///     groupId: 'things',             groupId: 'animals',            groupId: 'dogs'
		///     childGroupId: 'animals'        childGroupId: 'dogs'         },
		///   },                             },                             {
		///   {                              {                                name: 'Bulldog',
		///     name: 'Fruits',                name: 'Cats',                  value: 6,
		///     value: 3,                      value: 4,                      groupId: 'dogs'
		///     groupId: 'things',             groupId: 'animals',          },
		///     childGroupId: 'fruits'         childGroupId: 'cats',        {
		///   },                             },                               name: 'Shiba Inu',
		///   {                              {                                value: 7,
		///     name: 'Cars',                  name: 'Birds',                 groupId: 'dogs'
		///     value: 2,                      value: 3,                    }
		///     groupId: 'things',             groupId: 'animals',        ]
		///     childGroupId: 'cars'           childGroupId: 'birds'
		///   }                              }
		/// ]                              ]
		/// 
		/// 上面 3 组 data 分别来自 3 个 option ，通过groupId和childGroupId，它们之间存在了“父-子-孙”的关系。在setOption时，Apache ECharts 会尝试寻找前后option数据项间的父子关系，若存在父子关系，则会对相关数据项进行下钻或聚合动画的过渡。
		/// 没有对应子数据组的数据项不需要指定childGroupId。
		/// 如果你使用了dataset组件来表达数据，推荐使用encode.itemChildGroupId来指定哪个维度被编码为子数据组 ID。
		/// </summary>
		[JsonProperty("childGroupId")]
		public string ChildGroupId { get; set; }

		/// <summary>
		///SeriesCustom_Data_ItemStyle
		/// </summary>
		[JsonProperty("itemStyle")]
		public SeriesCustomDataItemStyle ItemStyle { get; set; }

		/// <summary>
		///SeriesCustom_Data_Emphasis
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomDataEmphasis Emphasis { get; set; }

		/// <summary>
		/// 本系列每个数据项中特定的 tooltip 设定。
		/// </summary>
		[JsonProperty("tooltip")]
		public SeriesCustomDataTooltip Tooltip { get; set; }
	}

	public class SeriesCustomDataTooltip
	{
		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的位置，默认不设置时位置会跟随鼠标的位置。
		/// 可选：
		/// 
		/// Array
		///   通过数组表示提示框浮层的位置，支持数字设置绝对位置，百分比设置相对位置。
		///   示例:
		///   // 绝对位置，相对于容器左侧 10px, 上侧 10 px
		///   position: [10, 10]
		///   // 相对位置，放置在容器正中间
		///   position: ['50%', '50%']
		/// 
		/// 
		/// Function
		///   回调函数，格式如下：
		///   (point: Array, params: Object|Array.<Object>, dom: HTMLDomElement, rect: Object, size: Object) => Array
		/// 
		///   参数：
		///   point: 鼠标位置，如 [20, 40]。
		///   params: 同 formatter 的参数相同。
		///   dom: tooltip 的 dom 对象。
		///   rect: 只有鼠标在图形上时有效，是一个用x, y, width, height四个属性表达的图形包围盒。
		///   size: 包括 dom 的尺寸和 echarts 容器的当前尺寸，例如：{contentSize: [width, height], viewSize: [width, height]}。
		///   返回值：
		///   可以是一个表示 tooltip 位置的数组，数组值可以是绝对的像素值，也可以是相  百分比。
		///   也可以是一个对象，如：{left: 10, top: 30}，或者 {right: '20%', bottom: 40}。
		///   如下示例：
		///   position: function (point, params, dom, rect, size) {
		///       // 固定在顶部
		///       return [point[0], '10%'];
		///   }
		/// 
		///   或者：
		///   position: function (pos, params, dom, rect, size) {
		///       // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
		///       var obj = {top: 60};
		///       obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5;
		///       return obj;
		///   }
		/// 
		/// 
		/// 
		/// 
		/// 'inside'
		///   鼠标所在图形的内部中心位置，只在 trigger 为'item'的时候有效。
		/// 
		/// 'top'
		///   鼠标所在图形上侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'left'
		///   鼠标所在图形左侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'right'
		///   鼠标所在图形右侧，只在 trigger 为'item'的时候有效。
		/// 
		/// 'bottom'
		///   鼠标所在图形底侧，只在 trigger 为'item'的时候有效。
		/// </summary>
		[JsonProperty("position")]
		public string[] Position { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层内容格式器，支持字符串模板和回调函数两种形式。
		/// 1. 字符串模板
		/// 模板变量有 {a}, {b}，{c}，{d}，{e}，分别表示系列名，数据名，数据值等。
		/// 在 trigger 为 'axis' 的时候，会有多个系列的数据，此时可以通过 {a0}, {a1}, {a2} 这种后面加索引的方式表示系列的索引。
		/// 不同图表类型下的 {a}，{b}，{c}，{d} 含义不一样。
		/// 其中变量{a}, {b}, {c}, {d}在不同图表类型下代表数据含义为：
		/// 
		/// 折线（区域）图、柱状（条形）图、K线图 : {a}（系列名称），{b}（类目值），{c}（数值）, {d}（无）
		/// 
		/// 散点图（气泡）图 : {a}（系列名称），{b}（数据名称），{c}（数值数组）, {d}（无）
		/// 
		/// 地图 : {a}（系列名称），{b}（区域名称），{c}（合并数值）, {d}（无）
		/// 
		/// 饼图、仪表盘、漏斗图: {a}（系列名称），{b}（数据项名称），{c}（数值）, {d}（百分比）
		/// 
		/// 
		/// 更多其它图表模板变量的含义可以见相应的图表的 label.formatter 配置项。
		/// 示例：
		/// formatter: '{b0}: {c0}<br />{b1}: {c1}'
		/// 
		/// 2. 回调函数
		/// 回调函数格式：
		/// (params: Object|Array, ticket: string, callback: (ticket: string, html: string)) => string | HTMLElement | HTMLElement[]
		/// 
		/// 支持返回 HTML 字符串或者创建的 DOM 实例。
		/// 第一个参数 params 是 formatter 需要的数据集。格式如下：
		/// {
		///     componentType: 'series',
		///     // 系列类型
		///     seriesType: string,
		///     // 系列在传入的 option.series 中的 index
		///     seriesIndex: number,
		///     // 系列名称
		///     seriesName: string,
		///     // 数据名，类目名
		///     name: string,
		///     // 数据在传入的 data 数组中的 index
		///     dataIndex: number,
		///     // 传入的原始数据项
		///     data: Object,
		///     // 传入的数据值。在多数系列下它和 data 相同。在一些系列下是 data 中的分量（如 map、radar 中）
		///     value: number|Array|Object,
		///     // 坐标轴 encode 映射信息，
		///     // key 为坐标轴（如 'x' 'y' 'radius' 'angle' 等）
		///     // value 必然为数组，不会为 null/undefined，表示 dimension index 。
		///     // 其内容如：
		///     // {
		///     //     x: [2] // dimension index 为 2 的数据映射到 x 轴
		///     //     y: [0] // dimension index 为 0 的数据映射到 y 轴
		///     // }
		///     encode: Object,
		///     // 维度名列表
		///     dimensionNames: Array<String>,
		///     // 数据的维度 index，如 0 或 1 或 2 ...
		///     // 仅在雷达图中使用。
		///     dimensionIndex: number,
		///     // 数据图形的颜色
		///     color: string,
		///     // 饼图/漏斗图的百分比
		///     percent: number,
		///     // 旭日图中当前节点的祖先节点（包括自身）
		///     treePathInfo: Array,
		///     // 树图/矩形树图中当前节点的祖先节点（包括自身）
		///     treeAncestors: Array
		/// }
		/// 
		/// 注：encode 和 dimensionNames 的使用方式，例如：
		/// 如果数据为：
		/// dataset: {
		///     source: [
		///         ['Matcha Latte', 43.3, 85.8, 93.7],
		///         ['Milk Tea', 83.1, 73.4, 55.1],
		///         ['Cheese Cocoa', 86.4, 65.2, 82.5],
		///         ['Walnut Brownie', 72.4, 53.9, 39.1]
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.encode.y[0]]
		/// 
		/// 如果数据为：
		/// dataset: {
		///     dimensions: ['product', '2015', '2016', '2017'],
		///     source: [
		///         {product: 'Matcha Latte', '2015': 43.3, '2016': 85.8, '2017': 93.7},
		///         {product: 'Milk Tea', '2015': 83.1, '2016': 73.4, '2017': 55.1},
		///         {product: 'Cheese Cocoa', '2015': 86.4, '2016': 65.2, '2017': 82.5},
		///         {product: 'Walnut Brownie', '2015': 72.4, '2016': 53.9, '2017': 39.1}
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.dimensionNames[params.encode.y[0]]]
		/// 
		/// 在 trigger 为 'axis' 的时候，或者 tooltip 被 axisPointer 触发的时候，params 是多个系列的数据数组。其中每项内容格式同上，并且，
		/// {
		///     componentType: 'series',
		///     // 系列类型
		///     seriesType: string,
		///     // 系列在传入的 option.series 中的 index
		///     seriesIndex: number,
		///     // 系列名称
		///     seriesName: string,
		///     // 数据名，类目名
		///     name: string,
		///     // 数据在传入的 data 数组中的 index
		///     dataIndex: number,
		///     // 传入的原始数据项
		///     data: Object,
		///     // 传入的数据值。在多数系列下它和 data 相同。在一些系列下是 data 中的分量（如 map、radar 中）
		///     value: number|Array|Object,
		///     // 坐标轴 encode 映射信息，
		///     // key 为坐标轴（如 'x' 'y' 'radius' 'angle' 等）
		///     // value 必然为数组，不会为 null/undefined，表示 dimension index 。
		///     // 其内容如：
		///     // {
		///     //     x: [2] // dimension index 为 2 的数据映射到 x 轴
		///     //     y: [0] // dimension index 为 0 的数据映射到 y 轴
		///     // }
		///     encode: Object,
		///     // 维度名列表
		///     dimensionNames: Array<String>,
		///     // 数据的维度 index，如 0 或 1 或 2 ...
		///     // 仅在雷达图中使用。
		///     dimensionIndex: number,
		///     // 数据图形的颜色
		///     color: string
		/// }
		/// 
		/// 注：encode 和 dimensionNames 的使用方式，例如：
		/// 如果数据为：
		/// dataset: {
		///     source: [
		///         ['Matcha Latte', 43.3, 85.8, 93.7],
		///         ['Milk Tea', 83.1, 73.4, 55.1],
		///         ['Cheese Cocoa', 86.4, 65.2, 82.5],
		///         ['Walnut Brownie', 72.4, 53.9, 39.1]
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.encode.y[0]]
		/// 
		/// 如果数据为：
		/// dataset: {
		///     dimensions: ['product', '2015', '2016', '2017'],
		///     source: [
		///         {product: 'Matcha Latte', '2015': 43.3, '2016': 85.8, '2017': 93.7},
		///         {product: 'Milk Tea', '2015': 83.1, '2016': 73.4, '2017': 55.1},
		///         {product: 'Cheese Cocoa', '2015': 86.4, '2016': 65.2, '2017': 82.5},
		///         {product: 'Walnut Brownie', '2015': 72.4, '2016': 53.9, '2017': 39.1}
		///     ]
		/// }
		/// 
		/// 则可这样得到 y 轴对应的 value：
		/// params.value[params.dimensionNames[params.encode.y[0]]]
		/// 
		/// 第二个参数 ticket 是异步回调标识，配合第三个参数 callback 使用。
		/// 第三个参数 callback 是异步回调，在提示框浮层内容是异步获取的时候，可以通过 callback 传入上述的 ticket 和 html 更新提示框浮层内容。
		/// 示例：
		/// formatter: function (params, ticket, callback) {
		///     $.get('detail?name=' + params.name, function (content) {
		///         callback(ticket, toHTML(content));
		///     });
		///     return 'Loading';
		/// }
		/// </summary>
		[JsonProperty("formatter")]
		public string Formatter { get; set; }

		/// <summary>
		/// 从 v5.3.0 开始支持
		/// 
		/// tooltip 中数值显示部分的格式化回调函数。
		/// 回调函数格式：
		/// (value: number | string, dataIndex: number) => string
		/// 
		/// 
		/// 自 v5.5.0 版本起提供 dataIndex。
		/// 
		/// 示例：
		/// // 添加 $ 前缀
		/// valueFormatter: (value) => '$' + value.toFixed(2)
		/// </summary>
		[JsonProperty("valueFormatter")]
		public string ValueFormatter { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的背景颜色。
		/// </summary>
		[JsonProperty("backgroundColor")]
		public Color BackgroundColor { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的边框颜色。
		/// </summary>
		[JsonProperty("borderColor")]
		public Color BorderColor { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的边框宽。
		/// </summary>
		[JsonProperty("borderWidth")]
		public double? BorderWidth { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 
		/// 
		/// 提示框浮层内边距，单位px，默认各方向内边距为5，接受数组分别设定上右下左边距。
		/// 使用示例：
		/// // 设置内边距为 5
		/// padding: 5
		/// // 设置上下的内边距为 5，左右的内边距为 10
		/// padding: [5, 10]
		/// // 分别设置四个方向的内边距
		/// padding: [
		///     5,  // 上
		///     10, // 右
		///     5,  // 下
		///     10, // 左
		/// ]
		/// </summary>
		[JsonProperty("padding")]
		public StringOrNumber[] Padding { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 提示框浮层的文本样式。
		/// </summary>
		[JsonProperty("textStyle")]
		public SeriesCustomDataTooltipTextStyle TextStyle { get; set; }

		/// <summary>
		/// 注意：series.data.tooltip 仅在 tooltip.trigger 为 'item' 时有效。
		/// 
		/// 额外附加到浮层的 css 样式。如下为浮层添加阴影的示例：
		/// extraCssText: 'box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);'
		/// </summary>
		[JsonProperty("extraCssText")]
		public string ExtraCssText { get; set; }
	}

	public class SeriesCustomDataTooltipTextStyle
	{
		/// <summary>
		/// 文字的颜色。
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 文字字体的风格。
		/// 可选：
		/// 
		/// 'normal'
		/// 'italic'
		/// 'oblique'
		/// </summary>
		[JsonProperty("fontStyle")]
		public string FontStyle { get; set; }

		/// <summary>
		/// 文字字体的粗细。
		/// 可选：
		/// 
		/// 'normal'
		/// 'bold'
		/// 'bolder'
		/// 'lighter'
		/// 100 | 200 | 300 | 400...
		/// </summary>
		[JsonProperty("fontWeight")]
		public string FontWeight { get; set; }

		/// <summary>
		/// 文字的字体系列。
		/// 还可以是 'serif' , 'monospace', 'Arial', 'Courier New', 'Microsoft YaHei', ...
		/// </summary>
		[JsonProperty("fontFamily")]
		public string FontFamily { get; set; }

		/// <summary>
		/// 文字的字体大小。
		/// </summary>
		[JsonProperty("fontSize")]
		public double? FontSize { get; set; }

		/// <summary>
		/// 行高。
		/// rich 中如果没有设置 lineHeight，则会取父层级的 lineHeight。例如：
		/// {
		///     lineHeight: 56,
		///     rich: {
		///         a: {
		///             // 没有设置 `lineHeight`，则 `lineHeight` 为 56
		///         }
		///     }
		/// }
		/// </summary>
		[JsonProperty("lineHeight")]
		public double? LineHeight { get; set; }

		/// <summary>
		/// 文本显示宽度。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 文本显示高度。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 文字本身的描边颜色。
		/// </summary>
		[JsonProperty("textBorderColor")]
		public Color TextBorderColor { get; set; }

		/// <summary>
		/// 文字本身的描边宽度。
		/// </summary>
		[JsonProperty("textBorderWidth")]
		public double? TextBorderWidth { get; set; }

		/// <summary>
		/// 文字本身的描边类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// textBorderDashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// textBorderType: [5, 10],
		/// 
		/// textBorderDashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("textBorderType")]
		public string TextBorderType { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// textBorderType
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("textBorderDashOffset")]
		public double? TextBorderDashOffset { get; set; }

		/// <summary>
		/// 文字本身的阴影颜色。
		/// </summary>
		[JsonProperty("textShadowColor")]
		public Color TextShadowColor { get; set; }

		/// <summary>
		/// 文字本身的阴影长度。
		/// </summary>
		[JsonProperty("textShadowBlur")]
		public double? TextShadowBlur { get; set; }

		/// <summary>
		/// 文字本身的阴影 X 偏移。
		/// </summary>
		[JsonProperty("textShadowOffsetX")]
		public double? TextShadowOffsetX { get; set; }

		/// <summary>
		/// 文字本身的阴影 Y 偏移。
		/// </summary>
		[JsonProperty("textShadowOffsetY")]
		public double? TextShadowOffsetY { get; set; }

		/// <summary>
		/// 文字超出宽度是否截断或者换行。配置width时有效
		/// 
		/// 'truncate' 截断，并在末尾显示ellipsis配置的文本，默认为...
		/// 'break' 换行
		/// 'breakAll' 换行，跟'break'不同的是，在英语等拉丁文中，'breakAll'还会强制单词内换行
		/// </summary>
		[JsonProperty("overflow")]
		public string Overflow { get; set; }

		/// <summary>
		/// 在overflow配置为'truncate'的时候，可以通过该属性配置末尾显示的文本。
		/// </summary>
		[JsonProperty("ellipsis")]
		public string Ellipsis { get; set; }
	}

	public class SeriesCustomDataEmphasis
	{
		/// <summary>
		///SeriesCustom_Data_Emphasis_ItemStyle
		/// </summary>
		[JsonProperty("itemStyle")]
		public SeriesCustomDataEmphasisItemStyle ItemStyle { get; set; }
	}

	public class SeriesCustomDataEmphasisItemStyle
	{
		/// <summary>
		/// 图形的颜色。
		/// 
		/// 支持使用rgb(255,255,255)，rgba(255,255,255,1)，#fff等方式设置为纯色，也支持设置为渐变色和纹理填充，具体见option.color
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 图形的描边颜色。支持的颜色格式同 color，不支持回调函数。
		/// </summary>
		[JsonProperty("borderColor")]
		public Color BorderColor { get; set; }

		/// <summary>
		/// 描边线宽。为 0 时无描边。
		/// </summary>
		[JsonProperty("borderWidth")]
		public double? BorderWidth { get; set; }

		/// <summary>
		/// 描边类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// borderDashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// borderType: [5, 10],
		/// 
		/// borderDashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("borderType")]
		public string BorderType { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// borderType
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("borderDashOffset")]
		public double? BorderDashOffset { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于指定线段末端的绘制方式，可以是：
		/// 
		/// 'butt': 线段末端以方形结束。
		/// 'round': 线段末端以圆形结束。
		/// 'square': 线段末端以方形结束，但是增加了一个宽度和线段相同，高度是线段厚度一半的矩形区域。
		/// 
		/// 默认值为 'butt'。 更多详情可以参考 MDN lineCap。
		/// </summary>
		[JsonProperty("borderCap")]
		public string BorderCap { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置2个长度不为0的相连部分（线段，圆弧，曲线）如何连接在一起的属性（长度为0的变形部分，其指定的末端和控制点在同一位置，会被忽略）。
		/// 可以是：
		/// 
		/// 'bevel': 在相连部分的末端填充一个额外的以三角形为底的区域， 每个部分都有各自独立的矩形拐角。
		/// 'round': 通过填充一个额外的，圆心在相连部分末端的扇形，绘制拐角的形状。 圆角的半径是线段的宽度。
		/// 'miter': 通过延伸相连部分的外边缘，使其相交于一点，形成一个额外的菱形区域。这个设置可以通过 
		/// borderMiterLimit
		/// 属性看到效果。
		/// 
		/// 默认值为 'bevel'。 更多详情可以参考 MDN lineJoin。
		/// </summary>
		[JsonProperty("borderJoin")]
		public string BorderJoin { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置斜接面限制比例。只有当 
		/// borderJoin
		///  为 miter 时，
		/// borderMiterLimit
		///  才有效。
		/// 默认值为 10。负数、0、Infinity 和 NaN 均会被忽略。
		/// 更多详情可以参考 MDN miterLimit。
		/// </summary>
		[JsonProperty("borderMiterLimit")]
		public double? BorderMiterLimit { get; set; }

		/// <summary>
		/// 图形阴影的模糊大小。该属性配合 shadowColor,shadowOffsetX, shadowOffsetY 一起设置图形的阴影效果。
		/// 示例：
		/// {
		///     shadowColor: 'rgba(0, 0, 0, 0.5)',
		///     shadowBlur: 10
		/// }
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影颜色。支持的格式同color。
		/// </summary>
		[JsonProperty("shadowColor")]
		public Color ShadowColor { get; set; }

		/// <summary>
		/// 阴影水平方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影垂直方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 图形透明度。支持从 0 到 1 的数字，为 0 时不绘制该图形。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }
	}

	public class SeriesCustomDataItemStyle
	{
		/// <summary>
		/// 图形的颜色。
		/// 
		/// 支持使用rgb(255,255,255)，rgba(255,255,255,1)，#fff等方式设置为纯色，也支持设置为渐变色和纹理填充，具体见option.color
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 图形的描边颜色。支持的颜色格式同 color，不支持回调函数。
		/// </summary>
		[JsonProperty("borderColor")]
		public Color BorderColor { get; set; }

		/// <summary>
		/// 描边线宽。为 0 时无描边。
		/// </summary>
		[JsonProperty("borderWidth")]
		public double? BorderWidth { get; set; }

		/// <summary>
		/// 描边类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// borderDashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// borderType: [5, 10],
		/// 
		/// borderDashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("borderType")]
		public string BorderType { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// borderType
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("borderDashOffset")]
		public double? BorderDashOffset { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于指定线段末端的绘制方式，可以是：
		/// 
		/// 'butt': 线段末端以方形结束。
		/// 'round': 线段末端以圆形结束。
		/// 'square': 线段末端以方形结束，但是增加了一个宽度和线段相同，高度是线段厚度一半的矩形区域。
		/// 
		/// 默认值为 'butt'。 更多详情可以参考 MDN lineCap。
		/// </summary>
		[JsonProperty("borderCap")]
		public string BorderCap { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置2个长度不为0的相连部分（线段，圆弧，曲线）如何连接在一起的属性（长度为0的变形部分，其指定的末端和控制点在同一位置，会被忽略）。
		/// 可以是：
		/// 
		/// 'bevel': 在相连部分的末端填充一个额外的以三角形为底的区域， 每个部分都有各自独立的矩形拐角。
		/// 'round': 通过填充一个额外的，圆心在相连部分末端的扇形，绘制拐角的形状。 圆角的半径是线段的宽度。
		/// 'miter': 通过延伸相连部分的外边缘，使其相交于一点，形成一个额外的菱形区域。这个设置可以通过 
		/// borderMiterLimit
		/// 属性看到效果。
		/// 
		/// 默认值为 'bevel'。 更多详情可以参考 MDN lineJoin。
		/// </summary>
		[JsonProperty("borderJoin")]
		public string BorderJoin { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置斜接面限制比例。只有当 
		/// borderJoin
		///  为 miter 时，
		/// borderMiterLimit
		///  才有效。
		/// 默认值为 10。负数、0、Infinity 和 NaN 均会被忽略。
		/// 更多详情可以参考 MDN miterLimit。
		/// </summary>
		[JsonProperty("borderMiterLimit")]
		public double? BorderMiterLimit { get; set; }

		/// <summary>
		/// 图形阴影的模糊大小。该属性配合 shadowColor,shadowOffsetX, shadowOffsetY 一起设置图形的阴影效果。
		/// 示例：
		/// {
		///     shadowColor: 'rgba(0, 0, 0, 0.5)',
		///     shadowBlur: 10
		/// }
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影颜色。支持的格式同color。
		/// </summary>
		[JsonProperty("shadowColor")]
		public Color ShadowColor { get; set; }

		/// <summary>
		/// 阴影水平方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影垂直方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 图形透明度。支持从 0 到 1 的数字，为 0 时不绘制该图形。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 图形的贴花图案，在 aria.enabled 与 aria.decal.show 都是 true 的情况下才生效。
		/// 如果为 'none' 表示不使用贴花图案。
		/// </summary>
		[JsonProperty("decal")]
		public SeriesCustomDataItemStyleDecal Decal { get; set; }
	}

	public class SeriesCustomDataItemStyleDecal
	{
		/// <summary>
		/// 贴花的图案，如果是 string[] 表示循环使用数组中的图案。
		/// ECharts 提供的标记类型包括
		/// 'circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow', 'none'
		/// 可以通过 'image://url' 设置为图片，其中 URL 为图片的链接，或者 dataURI。
		/// URL 为图片链接例如：
		/// 'image://http://example.website/a/b.png'
		/// URL 为 dataURI 例如：
		/// 'image://data:image/gif;base64,R0lGODlhEAAQAMQAAORHHOVSKudfOulrSOp3WOyDZu6QdvCchPGolfO0o/XBs/fNwfjZ0frl3/zy7////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAkAABAALAAAAAAQABAAAAVVICSOZGlCQAosJ6mu7fiyZeKqNKToQGDsM8hBADgUXoGAiqhSvp5QAnQKGIgUhwFUYLCVDFCrKUE1lBavAViFIDlTImbKC5Gm2hB0SlBCBMQiB0UjIQA7'
		/// 可以通过 'path://' 将图标设置为任意的矢量路径。这种方式相比于使用图片的方式，不用担心因为缩放而产生锯齿或模糊，而且可以设置为任意颜色。路径图形会自适应调整为合适的大小。路径的格式参见 SVG PathData。可以从 Adobe Illustrator 等工具编辑导出。
		/// 例如：
		/// 'path://M30.9,53.2C16.8,53.2,5.3,41.7,5.3,27.6S16.8,2,30.9,2C45,2,56.4,13.5,56.4,27.6S45,53.2,30.9,53.2z M30.9,3.5C17.6,3.5,6.8,14.4,6.8,27.6c0,13.3,10.8,24.1,24.101,24.1C44.2,51.7,55,40.9,55,27.6C54.9,14.4,44.1,3.5,30.9,3.5z M36.9,35.8c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H36c0.5,0,0.9,0.4,0.9,1V35.8z M27.8,35.8 c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H27c0.5,0,0.9,0.4,0.9,1L27.8,35.8L27.8,35.8z'
		/// </summary>
		[JsonProperty("symbol")]
		public string[] Symbol { get; set; }

		/// <summary>
		/// 取值范围：0 到 1，表示占图案区域的百分比。
		/// </summary>
		[JsonProperty("symbolSize")]
		public double? SymbolSize { get; set; }

		/// <summary>
		/// 是否保持图案的长宽比。
		/// </summary>
		[JsonProperty("symbolKeepAspect")]
		public bool? SymbolKeepAspect { get; set; }

		/// <summary>
		/// 贴花图案的颜色，建议使用半透明色，这样能叠加在系列本身的颜色上。
		/// </summary>
		[JsonProperty("color")]
		public string Color { get; set; }

		/// <summary>
		/// 贴花的背景色，将会覆盖在系列本身颜色之上，贴花图案之下。
		/// </summary>
		[JsonProperty("backgroundColor")]
		public string BackgroundColor { get; set; }

		/// <summary>
		/// 贴花图案的基本模式是在横向和纵向上分别以图案 - 空白 - 图案 - 空白 - 图案 - 空白的形式无限循环。通过设置每个图案和空白的长度，可以实现复杂的图案效果。
		/// dashArrayX 控制了横向的图案模式。当其值为 number 或 number[] 类型时，与 SVG stroke-dasharray 类似。
		/// 
		/// 如果是 number 类型，表示图案和空白分别是这个值。如 5 表示先显示宽度为 5 的图案，然后空 5 像素，再然后显示宽度为 5 的图案……
		/// 
		/// 如果是 number[] 类型，则表示图案和空白依次为数组值的循环。如：[5, 10, 2, 6] 表示图案宽 5 像素，然后空 10 像素，然后图案宽 2 像素，然后空 6 像素，然后图案宽 5 像素……
		/// 
		/// 如果是 (number | number[])[] 类型，表示每行的图案和空白依次为数组值的循环。如：[10, [2, 5]] 表示第一行以图案 10 像素空 10 像素循环，第二行以图案 2 像素空 5 像素循环，第三行以图案 10 像素空 10 像素循环……
		/// 
		/// 
		/// 可以结合以下的例子理解本接口：
		/// </summary>
		[JsonProperty("dashArrayX")]
		public ArrayOrSingle DashArrayX { get; set; }

		/// <summary>
		/// 贴花图案的基本模式是在横向和纵向上分别以图案 - 空白 - 图案 - 空白 - 图案 - 空白的形式无限循环。通过设置每个图案和空白的长度，可以实现复杂的图案效果。
		/// dashArrayY 控制了横向的图案模式。与 SVG stroke-dasharray 类似。
		/// 
		/// 如果是 number 类型，表示图案和空白分别是这个值。如 5 表示先显示高度为 5 的图案，然后空 5 像素，再然后显示高度为 5 的图案……
		/// 
		/// 如果是 number[] 类型，则表示图案和空白依次为数组值的循环。如：[5, 10, 2, 6] 表示图案高 5 像素，然后空 10 像素，然后图案高 2 像素，然后空 6 像素，然后图案高 5 像素……
		/// 
		/// 
		/// 可以结合以下的例子理解本接口：
		/// </summary>
		[JsonProperty("dashArrayY")]
		public ArrayOrSingle DashArrayY { get; set; }

		/// <summary>
		/// 图案的整体旋转角度（弧度制），取值范围从 -Math.PI 到 Math.PI。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 生成的图案在未重复之前的宽度上限。通常不需要设置该值，当你发现图案在重复的时候出现不连续的接缝时，可以尝试提高该值。
		/// </summary>
		[JsonProperty("maxTileWidth")]
		public double? MaxTileWidth { get; set; }

		/// <summary>
		/// 生成的图案在未重复之前的高度上限。通常不需要设置该值，当你发现图案在重复的时候出现不连续的接缝时，可以尝试提高该值。
		/// </summary>
		[JsonProperty("maxTileHeight")]
		public double? MaxTileHeight { get; set; }
	}

	public class SeriesCustomLabelLayout
	{
		/// <summary>
		/// 是否隐藏重叠的标签。
		/// 下面示例演示了在关系图中开启该配置后，在缩放时可以实现自动的标签隐藏。
		/// </summary>
		[JsonProperty("hideOverlap")]
		public bool? HideOverlap { get; set; }

		/// <summary>
		/// 在标签重叠的时候是否挪动标签位置以防止重叠。
		/// 目前支持配置为：
		/// 
		/// 'shiftX' 水平方向依次位移，在水平方向对齐时使用
		/// 'shiftY' 垂直方向依次位移，在垂直方向对齐时使用
		/// 
		/// 下面是标签右对齐并配置垂直方向依次位移以防止重叠的示例。
		/// </summary>
		[JsonProperty("moveOverlap")]
		public string MoveOverlap { get; set; }

		/// <summary>
		/// 标签的 x 位置。支持绝对的像素值或者'20%'这样的相对值。
		/// </summary>
		[JsonProperty("x")]
		public StringOrNumber X { get; set; }

		/// <summary>
		/// 标签的 y 位置。支持绝对的像素值或者'20%'这样的相对值。
		/// </summary>
		[JsonProperty("y")]
		public StringOrNumber Y { get; set; }

		/// <summary>
		/// 标签在 x 方向上的像素偏移。可以和x一起使用。
		/// </summary>
		[JsonProperty("dx")]
		public double? Dx { get; set; }

		/// <summary>
		/// 标签在 y 方向上的像素偏移。可以和y一起使用
		/// </summary>
		[JsonProperty("dy")]
		public double? Dy { get; set; }

		/// <summary>
		/// 标签旋转角度。
		/// </summary>
		[JsonProperty("rotate")]
		public double? Rotate { get; set; }

		/// <summary>
		/// 标签显示的宽度。可以配合overflow使用控制标签显示在固定宽度内
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 标签显示的高度。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 标签水平对齐方式。可以设置'left', 'center', 'right'。
		/// </summary>
		[JsonProperty("align")]
		public string Align { get; set; }

		/// <summary>
		/// 标签垂直对齐方式。可以设置'top', 'middle', 'bottom'。
		/// </summary>
		[JsonProperty("verticalAlign")]
		public string VerticalAlign { get; set; }

		/// <summary>
		/// The text size of the label.
		/// </summary>
		[JsonProperty("fontSize")]
		public double? FontSize { get; set; }

		/// <summary>
		/// 标签是否可以允许用户通过拖拽二次调整位置。
		/// </summary>
		[JsonProperty("draggable")]
		public bool? Draggable { get; set; }

		/// <summary>
		/// 标签引导线三个点的位置。格式为：
		/// [[x, y], [x, y], [x, y]]
		/// 
		/// 在饼图中常用来微调已经计算好的引导线，其它情况一般不建议设置。
		/// </summary>
		[JsonProperty("labelLinePoints")]
		public double[] LabelLinePoints { get; set; }
	}

	public class SeriesCustomLabelLine
	{
		/// <summary>
		/// 是否显示视觉引导线。
		/// </summary>
		[JsonProperty("show")]
		public bool? Show { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 是否显示在图形上方。
		/// </summary>
		[JsonProperty("showAbove")]
		public bool? ShowAbove { get; set; }

		/// <summary>
		/// 视觉引导项第二段的长度。
		/// </summary>
		[JsonProperty("length2")]
		public double? Length2 { get; set; }

		/// <summary>
		/// 是否平滑视觉引导线，默认不平滑，可以设置成 true 平滑显示，也可以设置为 0 到 1 的值，表示平滑程度。
		/// </summary>
		[JsonProperty("smooth")]
		public bool? Smooth { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 通过调整第二段线的长度，限制引导线两端之间最小的夹角，以防止过小的夹角导致显示不美观。
		/// 可以设置为 0 - 180 度。
		/// </summary>
		[JsonProperty("minTurnAngle")]
		public double? MinTurnAngle { get; set; }

		/// <summary>
		///SeriesCustom_LabelLine_LineStyle
		/// </summary>
		[JsonProperty("lineStyle")]
		public SeriesCustomLabelLineLineStyle LineStyle { get; set; }
	}

	public class SeriesCustomLabelLineLineStyle
	{
		/// <summary>
		/// 线的颜色。
		/// 
		/// 支持使用rgb(255,255,255)，rgba(255,255,255,1)，#fff等方式设置为纯色，也支持设置为渐变色和纹理填充，具体见option.color
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 线宽。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 线的类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// dashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// type: [5, 10],
		/// 
		/// dashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// type
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("dashOffset")]
		public double? DashOffset { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于指定线段末端的绘制方式，可以是：
		/// 
		/// 'butt': 线段末端以方形结束。
		/// 'round': 线段末端以圆形结束。
		/// 'square': 线段末端以方形结束，但是增加了一个宽度和线段相同，高度是线段厚度一半的矩形区域。
		/// 
		/// 默认值为 'butt'。 更多详情可以参考 MDN lineCap。
		/// </summary>
		[JsonProperty("cap")]
		public string Cap { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置2个长度不为0的相连部分（线段，圆弧，曲线）如何连接在一起的属性（长度为0的变形部分，其指定的末端和控制点在同一位置，会被忽略）。
		/// 可以是：
		/// 
		/// 'bevel': 在相连部分的末端填充一个额外的以三角形为底的区域， 每个部分都有各自独立的矩形拐角。
		/// 'round': 通过填充一个额外的，圆心在相连部分末端的扇形，绘制拐角的形状。 圆角的半径是线段的宽度。
		/// 'miter': 通过延伸相连部分的外边缘，使其相交于一点，形成一个额外的菱形区域。这个设置可以通过 
		/// miterLimit
		/// 属性看到效果。
		/// 
		/// 默认值为 'bevel'。 更多详情可以参考 MDN lineJoin。
		/// </summary>
		[JsonProperty("join")]
		public string Join { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置斜接面限制比例。只有当 
		/// join
		///  为 miter 时，
		/// miterLimit
		///  才有效。
		/// 默认值为 10。负数、0、Infinity 和 NaN 均会被忽略。
		/// 更多详情可以参考 MDN miterLimit。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 图形阴影的模糊大小。该属性配合 shadowColor,shadowOffsetX, shadowOffsetY 一起设置图形的阴影效果。
		/// 示例：
		/// {
		///     shadowColor: 'rgba(0, 0, 0, 0.5)',
		///     shadowBlur: 10
		/// }
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影颜色。支持的格式同color。
		/// </summary>
		[JsonProperty("shadowColor")]
		public Color ShadowColor { get; set; }

		/// <summary>
		/// 阴影水平方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影垂直方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 图形透明度。支持从 0 到 1 的数字，为 0 时不绘制该图形。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }
	}

	public class SeriesCustomItemStyle
	{
		/// <summary>
		/// 图形的颜色。 默认从全局调色盘 option.color 获取颜色。
		/// 
		/// 支持使用rgb(255,255,255)，rgba(255,255,255,1)，#fff等方式设置为纯色，也支持设置为渐变色和纹理填充，具体见option.color
		/// </summary>
		[JsonProperty("color")]
		public Color Color { get; set; }

		/// <summary>
		/// 图形的描边颜色。支持的颜色格式同 color，不支持回调函数。
		/// </summary>
		[JsonProperty("borderColor")]
		public Color BorderColor { get; set; }

		/// <summary>
		/// 描边线宽。为 0 时无描边。
		/// </summary>
		[JsonProperty("borderWidth")]
		public double? BorderWidth { get; set; }

		/// <summary>
		/// 描边类型。
		/// 可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// 
		/// 自 v5.0.0 开始，也可以是 number 或者 number 数组，用以指定线条的 dash array，配合 
		/// borderDashOffset
		///  可实现更灵活的虚线效果。
		/// 例如：
		/// {
		/// 
		/// borderType: [5, 10],
		/// 
		/// borderDashOffset: 5
		/// }
		/// </summary>
		[JsonProperty("borderType")]
		public string BorderType { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置虚线的偏移量，可搭配 
		/// borderType
		///  指定 dash array 实现灵活的虚线效果。
		/// 更多详情可以参考 MDN lineDashOffset。
		/// </summary>
		[JsonProperty("borderDashOffset")]
		public double? BorderDashOffset { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于指定线段末端的绘制方式，可以是：
		/// 
		/// 'butt': 线段末端以方形结束。
		/// 'round': 线段末端以圆形结束。
		/// 'square': 线段末端以方形结束，但是增加了一个宽度和线段相同，高度是线段厚度一半的矩形区域。
		/// 
		/// 默认值为 'butt'。 更多详情可以参考 MDN lineCap。
		/// </summary>
		[JsonProperty("borderCap")]
		public string BorderCap { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置2个长度不为0的相连部分（线段，圆弧，曲线）如何连接在一起的属性（长度为0的变形部分，其指定的末端和控制点在同一位置，会被忽略）。
		/// 可以是：
		/// 
		/// 'bevel': 在相连部分的末端填充一个额外的以三角形为底的区域， 每个部分都有各自独立的矩形拐角。
		/// 'round': 通过填充一个额外的，圆心在相连部分末端的扇形，绘制拐角的形状。 圆角的半径是线段的宽度。
		/// 'miter': 通过延伸相连部分的外边缘，使其相交于一点，形成一个额外的菱形区域。这个设置可以通过 
		/// borderMiterLimit
		/// 属性看到效果。
		/// 
		/// 默认值为 'bevel'。 更多详情可以参考 MDN lineJoin。
		/// </summary>
		[JsonProperty("borderJoin")]
		public string BorderJoin { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 
		/// 
		/// 用于设置斜接面限制比例。只有当 
		/// borderJoin
		///  为 miter 时，
		/// borderMiterLimit
		///  才有效。
		/// 默认值为 10。负数、0、Infinity 和 NaN 均会被忽略。
		/// 更多详情可以参考 MDN miterLimit。
		/// </summary>
		[JsonProperty("borderMiterLimit")]
		public double? BorderMiterLimit { get; set; }

		/// <summary>
		/// 图形阴影的模糊大小。该属性配合 shadowColor,shadowOffsetX, shadowOffsetY 一起设置图形的阴影效果。
		/// 示例：
		/// {
		///     shadowColor: 'rgba(0, 0, 0, 0.5)',
		///     shadowBlur: 10
		/// }
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影颜色。支持的格式同color。
		/// </summary>
		[JsonProperty("shadowColor")]
		public Color ShadowColor { get; set; }

		/// <summary>
		/// 阴影水平方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影垂直方向上的偏移距离。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 图形透明度。支持从 0 到 1 的数字，为 0 时不绘制该图形。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 图形的贴花图案，在 aria.enabled 与 aria.decal.show 都是 true 的情况下才生效。
		/// 如果为 'none' 表示不使用贴花图案。
		/// </summary>
		[JsonProperty("decal")]
		public SeriesCustomItemStyleDecal Decal { get; set; }
	}

	public class SeriesCustomItemStyleDecal
	{
		/// <summary>
		/// 贴花的图案，如果是 string[] 表示循环使用数组中的图案。
		/// ECharts 提供的标记类型包括
		/// 'circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow', 'none'
		/// 可以通过 'image://url' 设置为图片，其中 URL 为图片的链接，或者 dataURI。
		/// URL 为图片链接例如：
		/// 'image://http://example.website/a/b.png'
		/// URL 为 dataURI 例如：
		/// 'image://data:image/gif;base64,R0lGODlhEAAQAMQAAORHHOVSKudfOulrSOp3WOyDZu6QdvCchPGolfO0o/XBs/fNwfjZ0frl3/zy7////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAkAABAALAAAAAAQABAAAAVVICSOZGlCQAosJ6mu7fiyZeKqNKToQGDsM8hBADgUXoGAiqhSvp5QAnQKGIgUhwFUYLCVDFCrKUE1lBavAViFIDlTImbKC5Gm2hB0SlBCBMQiB0UjIQA7'
		/// 可以通过 'path://' 将图标设置为任意的矢量路径。这种方式相比于使用图片的方式，不用担心因为缩放而产生锯齿或模糊，而且可以设置为任意颜色。路径图形会自适应调整为合适的大小。路径的格式参见 SVG PathData。可以从 Adobe Illustrator 等工具编辑导出。
		/// 例如：
		/// 'path://M30.9,53.2C16.8,53.2,5.3,41.7,5.3,27.6S16.8,2,30.9,2C45,2,56.4,13.5,56.4,27.6S45,53.2,30.9,53.2z M30.9,3.5C17.6,3.5,6.8,14.4,6.8,27.6c0,13.3,10.8,24.1,24.101,24.1C44.2,51.7,55,40.9,55,27.6C54.9,14.4,44.1,3.5,30.9,3.5z M36.9,35.8c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H36c0.5,0,0.9,0.4,0.9,1V35.8z M27.8,35.8 c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H27c0.5,0,0.9,0.4,0.9,1L27.8,35.8L27.8,35.8z'
		/// </summary>
		[JsonProperty("symbol")]
		public string[] Symbol { get; set; }

		/// <summary>
		/// 取值范围：0 到 1，表示占图案区域的百分比。
		/// </summary>
		[JsonProperty("symbolSize")]
		public double? SymbolSize { get; set; }

		/// <summary>
		/// 是否保持图案的长宽比。
		/// </summary>
		[JsonProperty("symbolKeepAspect")]
		public bool? SymbolKeepAspect { get; set; }

		/// <summary>
		/// 贴花图案的颜色，建议使用半透明色，这样能叠加在系列本身的颜色上。
		/// </summary>
		[JsonProperty("color")]
		public string Color { get; set; }

		/// <summary>
		/// 贴花的背景色，将会覆盖在系列本身颜色之上，贴花图案之下。
		/// </summary>
		[JsonProperty("backgroundColor")]
		public string BackgroundColor { get; set; }

		/// <summary>
		/// 贴花图案的基本模式是在横向和纵向上分别以图案 - 空白 - 图案 - 空白 - 图案 - 空白的形式无限循环。通过设置每个图案和空白的长度，可以实现复杂的图案效果。
		/// dashArrayX 控制了横向的图案模式。当其值为 number 或 number[] 类型时，与 SVG stroke-dasharray 类似。
		/// 
		/// 如果是 number 类型，表示图案和空白分别是这个值。如 5 表示先显示宽度为 5 的图案，然后空 5 像素，再然后显示宽度为 5 的图案……
		/// 
		/// 如果是 number[] 类型，则表示图案和空白依次为数组值的循环。如：[5, 10, 2, 6] 表示图案宽 5 像素，然后空 10 像素，然后图案宽 2 像素，然后空 6 像素，然后图案宽 5 像素……
		/// 
		/// 如果是 (number | number[])[] 类型，表示每行的图案和空白依次为数组值的循环。如：[10, [2, 5]] 表示第一行以图案 10 像素空 10 像素循环，第二行以图案 2 像素空 5 像素循环，第三行以图案 10 像素空 10 像素循环……
		/// 
		/// 
		/// 可以结合以下的例子理解本接口：
		/// </summary>
		[JsonProperty("dashArrayX")]
		public ArrayOrSingle DashArrayX { get; set; }

		/// <summary>
		/// 贴花图案的基本模式是在横向和纵向上分别以图案 - 空白 - 图案 - 空白 - 图案 - 空白的形式无限循环。通过设置每个图案和空白的长度，可以实现复杂的图案效果。
		/// dashArrayY 控制了横向的图案模式。与 SVG stroke-dasharray 类似。
		/// 
		/// 如果是 number 类型，表示图案和空白分别是这个值。如 5 表示先显示高度为 5 的图案，然后空 5 像素，再然后显示高度为 5 的图案……
		/// 
		/// 如果是 number[] 类型，则表示图案和空白依次为数组值的循环。如：[5, 10, 2, 6] 表示图案高 5 像素，然后空 10 像素，然后图案高 2 像素，然后空 6 像素，然后图案高 5 像素……
		/// 
		/// 
		/// 可以结合以下的例子理解本接口：
		/// </summary>
		[JsonProperty("dashArrayY")]
		public ArrayOrSingle DashArrayY { get; set; }

		/// <summary>
		/// 图案的整体旋转角度（弧度制），取值范围从 -Math.PI 到 Math.PI。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 生成的图案在未重复之前的宽度上限。通常不需要设置该值，当你发现图案在重复的时候出现不连续的接缝时，可以尝试提高该值。
		/// </summary>
		[JsonProperty("maxTileWidth")]
		public double? MaxTileWidth { get; set; }

		/// <summary>
		/// 生成的图案在未重复之前的高度上限。通常不需要设置该值，当你发现图案在重复的时候出现不连续的接缝时，可以尝试提高该值。
		/// </summary>
		[JsonProperty("maxTileHeight")]
		public double? MaxTileHeight { get; set; }
	}

	public class SeriesCustomRenderItem
	{
		/// <summary>
		/// renderItem 函数的参数。
		/// </summary>
		[JsonProperty("arguments")]
		public SeriesCustomRenderItemArguments Arguments { get; set; }

		/// <summary>
		/// 图形元素。每个图形元素是一个 object。详细信息参见：graphic。（width\height\top\bottom 不支持）
		/// 如果什么都不渲染，可以不返回任何东西。
		/// 例如：
		/// // 单独一个矩形
		/// {
		///     type: 'rect',
		///     shape: {
		///         x: x, y: y, width: width, height: height
		///     },
		///     style: api.style()
		/// }
		/// 
		/// // 一组图形元素
		/// {
		///     type: 'group',
		///     // 如果 diffChildrenByName 设为 true，则会使用 child.name 进行 diff，
		///     // 从而能有更好的过度动画，但是降低性能。缺省为 false。
		///     // diffChildrenByName: true,
		///     children: [{
		///         type: 'circle',
		///         shape: {
		///             cx: cx, cy: cy, r: r
		///         },
		///         style: api.style()
		///     }, {
		///         type: 'line',
		///         shape: {
		///             x1: x1, y1: y1, x2: x2, y2: y2
		///         },
		///         style: api.style()
		///     }]
		/// }
		/// </summary>
		[JsonProperty("return")]
		public object Return { get; set; }

		/// <summary>
		/// group 是唯一的可以有子节点的容器。group 可以用来整体定位一组图形元素。
		/// 注意，如果其任意子节点是 null，这表示该子节点不再存在。所以，如果再次调用 setOption 时，一个子节点被设为 null，这意味着它之前对应序号的元素会被删除。如果希望一个子节点保持不变，应在新的配置项中使用 {} 表示。并且，仅当 group 的子节点在之前的 setOption 中存在时，才可以使用 null/undefined/{} 作为子节点。
		/// </summary>
		[JsonProperty("return_group")]
		public SeriesCustomRenderItemReturnGroup ReturnGroup { get; set; }

		/// <summary>
		/// 可使用 SVG PathData 做路径。
		/// 可以用来画图标，或者其他各种图形，因为可以很便捷得缩放以适应给定尺寸。
		/// 参见例子：
		/// icons 和 shapes。
		/// 关于制定尺寸、拉伸还是平铺，参见 layout。
		/// </summary>
		[JsonProperty("return_path")]
		public SeriesCustomRenderItemReturnPath ReturnPath { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_ReturnImage
		/// </summary>
		[JsonProperty("return_image")]
		public SeriesCustomRenderItemReturnImage ReturnImage { get; set; }

		/// <summary>
		/// 文本块。
		/// </summary>
		[JsonProperty("return_text")]
		public SeriesCustomRenderItemReturnText ReturnText { get; set; }

		/// <summary>
		/// 矩形。
		/// </summary>
		[JsonProperty("return_rect")]
		public SeriesCustomRenderItemReturnRect ReturnRect { get; set; }

		/// <summary>
		/// 圆。
		/// </summary>
		[JsonProperty("return_circle")]
		public SeriesCustomRenderItemReturnCircle ReturnCircle { get; set; }

		/// <summary>
		/// 圆环。
		/// </summary>
		[JsonProperty("return_ring")]
		public SeriesCustomRenderItemReturnRing ReturnRing { get; set; }

		/// <summary>
		/// 扇形。
		/// </summary>
		[JsonProperty("return_sector")]
		public SeriesCustomRenderItemReturnSector ReturnSector { get; set; }

		/// <summary>
		/// 圆弧。
		/// </summary>
		[JsonProperty("return_arc")]
		public SeriesCustomRenderItemReturnArc ReturnArc { get; set; }

		/// <summary>
		/// 多边形。
		/// </summary>
		[JsonProperty("return_polygon")]
		public SeriesCustomRenderItemReturnPolygon ReturnPolygon { get; set; }

		/// <summary>
		/// 折线。
		/// </summary>
		[JsonProperty("return_polyline")]
		public SeriesCustomRenderItemReturnPolyline ReturnPolyline { get; set; }

		/// <summary>
		/// 直线。
		/// </summary>
		[JsonProperty("return_line")]
		public SeriesCustomRenderItemReturnLine ReturnLine { get; set; }

		/// <summary>
		/// 二次或三次贝塞尔曲线。
		/// </summary>
		[JsonProperty("return_bezierCurve")]
		public SeriesCustomRenderItemReturnBezierCurve ReturnBezierCurve { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurve
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnBezierCurveEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnBezierCurveUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnBezierCurveLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnBezierCurveKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_BezierCurve_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnBezierCurveTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnBezierCurveExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_BezierCurve_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnBezierCurveShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnBezierCurveStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnBezierCurveEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnBezierCurveBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnBezierCurveSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveShape
	{
		/// <summary>
		/// 开始点的 x 值。
		/// </summary>
		[JsonProperty("x1")]
		public double? X1 { get; set; }

		/// <summary>
		/// 开始点的 y 值。
		/// </summary>
		[JsonProperty("y1")]
		public double? Y1 { get; set; }

		/// <summary>
		/// 结束点的 x 值。
		/// </summary>
		[JsonProperty("x2")]
		public double? X2 { get; set; }

		/// <summary>
		/// 结束点的 y 值。
		/// </summary>
		[JsonProperty("y2")]
		public double? Y2 { get; set; }

		/// <summary>
		/// 控制点 x 值。
		/// </summary>
		[JsonProperty("cpx1")]
		public double? Cpx1 { get; set; }

		/// <summary>
		/// 控制点 y 值。
		/// </summary>
		[JsonProperty("cpy1")]
		public double? Cpy1 { get; set; }

		/// <summary>
		/// 第二个控制点 x 值。如果设置则开启三阶贝塞尔曲线。
		/// </summary>
		[JsonProperty("cpx2")]
		public double? Cpx2 { get; set; }

		/// <summary>
		/// 第二个控制点 y 值。如果设置则开启三阶贝塞尔曲线。
		/// </summary>
		[JsonProperty("cpy2")]
		public double? Cpy2 { get; set; }

		/// <summary>
		/// 画到百分之多少就不画了。值的范围：[0, 1]。
		/// </summary>
		[JsonProperty("percent")]
		public double? Percent { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnBezierCurveEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnLine
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnLineEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnLineUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnLineLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnLineKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Line_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnLineTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnLineExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Line_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnLineShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnLineStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnLineEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnLineBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnLineSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineShape
	{
		/// <summary>
		/// 开始点的 x 值。
		/// </summary>
		[JsonProperty("x1")]
		public double? X1 { get; set; }

		/// <summary>
		/// 开始点的 y 值。
		/// </summary>
		[JsonProperty("y1")]
		public double? Y1 { get; set; }

		/// <summary>
		/// 结束点的 x 值。
		/// </summary>
		[JsonProperty("x2")]
		public double? X2 { get; set; }

		/// <summary>
		/// 结束点的 y 值。
		/// </summary>
		[JsonProperty("y2")]
		public double? Y2 { get; set; }

		/// <summary>
		/// 线画到百分之多少就不画了。值的范围：[0, 1]。
		/// </summary>
		[JsonProperty("percent")]
		public double? Percent { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnLineEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolyline
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnPolylineEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnPolylineUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnPolylineLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnPolylineKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Polyline_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnPolylineTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnPolylineExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Polyline_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnPolylineShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnPolylineStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnPolylineEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnPolylineBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnPolylineSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineShape
	{
		/// <summary>
		/// 点列表，用于定义形状，如 [[22, 44], [44, 55], [11, 44], ...]
		/// </summary>
		[JsonProperty("points")]
		public double[] Points { get; set; }

		/// <summary>
		/// 是否平滑曲线。
		/// 
		/// 如果为 number：表示贝塞尔 (bezier) 差值平滑，smooth 指定了平滑等级，范围 [0, 1]。
		/// 如果为 'spline'：表示 Catmull-Rom spline 差值平滑。
		/// </summary>
		[JsonProperty("smooth")]
		public StringOrNumber Smooth { get; set; }

		/// <summary>
		/// 是否将平滑曲线约束在包围盒中。smooth 为 number（bezier）时生效。
		/// </summary>
		[JsonProperty("smoothConstraint")]
		public bool? SmoothConstraint { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolylineEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygon
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnPolygonEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnPolygonUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnPolygonLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnPolygonKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Polygon_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnPolygonTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnPolygonExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Polygon_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnPolygonShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnPolygonStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnPolygonEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnPolygonBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnPolygonSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonShape
	{
		/// <summary>
		/// 点列表，用于定义形状，如 [[22, 44], [44, 55], [11, 44], ...]
		/// </summary>
		[JsonProperty("points")]
		public double[] Points { get; set; }

		/// <summary>
		/// 是否平滑曲线。
		/// 
		/// 如果为 number：表示贝塞尔 (bezier) 差值平滑，smooth 指定了平滑等级，范围 [0, 1]。
		/// 如果为 'spline'：表示 Catmull-Rom spline 差值平滑。
		/// </summary>
		[JsonProperty("smooth")]
		public StringOrNumber Smooth { get; set; }

		/// <summary>
		/// 是否将平滑曲线约束在包围盒中。smooth 为 number（bezier）时生效。
		/// </summary>
		[JsonProperty("smoothConstraint")]
		public bool? SmoothConstraint { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPolygonEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnArc
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnArcEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnArcUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnArcLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnArcKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Arc_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnArcTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnArcExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Arc_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnArcShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnArcStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnArcEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnArcBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnArcSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcShape
	{
		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("cx")]
		public double? Cx { get; set; }

		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("cy")]
		public double? Cy { get; set; }

		/// <summary>
		/// 外半径。
		/// </summary>
		[JsonProperty("r")]
		public double? R { get; set; }

		/// <summary>
		/// 内半径。
		/// </summary>
		[JsonProperty("r0")]
		public double? R0 { get; set; }

		/// <summary>
		/// 开始弧度。
		/// </summary>
		[JsonProperty("startAngle")]
		public double? StartAngle { get; set; }

		/// <summary>
		/// 结束弧度。
		/// </summary>
		[JsonProperty("endAngle")]
		public double? EndAngle { get; set; }

		/// <summary>
		/// 是否顺时针。
		/// </summary>
		[JsonProperty("clockwise")]
		public bool? Clockwise { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnArcEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnSector
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnSectorEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnSectorUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnSectorLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnSectorKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Sector_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnSectorTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnSectorExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Sector_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnSectorShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnSectorStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnSectorEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnSectorBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnSectorSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorShape
	{
		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("cx")]
		public double? Cx { get; set; }

		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("cy")]
		public double? Cy { get; set; }

		/// <summary>
		/// 外半径。
		/// </summary>
		[JsonProperty("r")]
		public double? R { get; set; }

		/// <summary>
		/// 内半径。
		/// </summary>
		[JsonProperty("r0")]
		public double? R0 { get; set; }

		/// <summary>
		/// 开始弧度。
		/// </summary>
		[JsonProperty("startAngle")]
		public double? StartAngle { get; set; }

		/// <summary>
		/// 结束弧度。
		/// </summary>
		[JsonProperty("endAngle")]
		public double? EndAngle { get; set; }

		/// <summary>
		/// 是否顺时针。
		/// </summary>
		[JsonProperty("clockwise")]
		public bool? Clockwise { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnSectorEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRing
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnRingEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnRingUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnRingLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnRingKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Ring_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnRingTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnRingExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Ring_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnRingShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnRingStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnRingEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnRingBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnRingSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingShape
	{
		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("cx")]
		public double? Cx { get; set; }

		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("cy")]
		public double? Cy { get; set; }

		/// <summary>
		/// 外半径。
		/// </summary>
		[JsonProperty("r")]
		public double? R { get; set; }

		/// <summary>
		/// 内半径。
		/// </summary>
		[JsonProperty("r0")]
		public double? R0 { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRingEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircle
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnCircleEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnCircleUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnCircleLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnCircleKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Circle_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnCircleTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnCircleExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Circle_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnCircleShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnCircleStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnCircleEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnCircleBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnCircleSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleShape
	{
		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("cx")]
		public double? Cx { get; set; }

		/// <summary>
		/// 图形元素的中心在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("cy")]
		public double? Cy { get; set; }

		/// <summary>
		/// 外半径。
		/// </summary>
		[JsonProperty("r")]
		public double? R { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnCircleEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRect
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnRectEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnRectUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnRectLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnRectKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Rect_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnRectTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnRectExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Rect_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnRectShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnRectStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnRectEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnRectBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnRectSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectShape
	{
		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 图形元素的宽度。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 图形元素的高度。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 可以用于设置圆角矩形。r: [r1, r2, r3, r4]，
		/// 左上、右上、右下、左下角的半径依次为r1、r2、r3、r4。
		/// 可以缩写，例如：
		/// 
		/// r 缩写为 1         相当于 [1, 1, 1, 1]
		/// r 缩写为 [1]       相当于 [1, 1, 1, 1]
		/// r 缩写为 [1, 2]    相当于 [1, 2, 1, 2]
		/// r 缩写为 [1, 2, 3]1 相当于[1, 2, 3, 2]`
		/// </summary>
		[JsonProperty("r")]
		public double[] R { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnRectEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnText
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnTextEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnTextUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnTextLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnTextKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Text_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnTextTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnTextExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Text_Style
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnTextStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnTextEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnTextBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnTextSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextStyle
	{
		/// <summary>
		/// 文本块文字。可以使用 \n 来换行。
		/// </summary>
		[JsonProperty("text")]
		public string Text { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 字体大小、字体类型、粗细、字体样式。格式参见 css font。
		/// 例如：
		/// // size | family
		/// font: '2em "STHeiti", sans-serif'
		/// 
		/// // style | weight | size | family
		/// font: 'italic bolder 16px cursive'
		/// 
		/// // weight | size | family
		/// font: 'bolder 2em "Microsoft YaHei", sans-serif'
		/// </summary>
		[JsonProperty("font")]
		public string Font { get; set; }

		/// <summary>
		/// 水平对齐方式，取值：'left', 'center', 'right'。
		/// 如果为 'left'，表示文本最左端在 x 值上。如果为 'right'，表示文本最右端在 x 值上。
		/// </summary>
		[JsonProperty("textAlign")]
		public string TextAlign { get; set; }

		/// <summary>
		/// 文本限制宽度，用于提供 overflow 的参考。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 当文本内容超出 width 时的文本显示策略，取值：'break', 'breakAll', 'truncate', 'none'。
		/// 
		/// 'break': 尽可能保证完整的单词不被截断(类似 CSS 中的 word-break: break-word;)
		/// 'breakAll': 可在任意字符间断行
		/// 'truncate': 截断文本屏显示 '...'，可以使用 ellipsis 来自定义省略号的显示
		/// 'none': 不换行
		/// </summary>
		[JsonProperty("overflow")]
		public string Overflow { get; set; }

		/// <summary>
		/// 当 overflow 设置为 'truncate' 时生效，默认为 ...。
		/// </summary>
		[JsonProperty("ellipsis")]
		public string Ellipsis { get; set; }

		/// <summary>
		/// 垂直对齐方式，取值：'top', 'middle', 'bottom'。
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("textVerticalAlign")]
		public string TextVerticalAlign { get; set; }

		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnTextEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnImage
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnImageEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnImageUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnImageLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnImageKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Image_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnImageTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnImageExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Image_Style
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnImageStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnImageEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnImageBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnImageSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageStyle
	{
		/// <summary>
		/// 图片的内容，可以是图片的 URL，也可以是 dataURI.
		/// </summary>
		[JsonProperty("image")]
		public string Image { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 图形元素的宽度。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 图形元素的高度。
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnImageEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPath
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnPathEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnPathUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnPathLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnPathKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 是否开启形变动画。
		/// 开启 universalTransition 后如果前后两次更新图形类型不一样，比如从rect变为了circle，会通过形变动画过渡。如果想要关闭可以设置该属性为false。
		/// </summary>
		[JsonProperty("morph")]
		public bool? Morph { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否可见。
		/// </summary>
		[JsonProperty("invisible")]
		public bool? Invisible { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Path_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnPathTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnPathExtra Extra { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Path_Shape
		/// </summary>
		[JsonProperty("shape")]
		public SeriesCustomRenderItemReturnPathShape Shape { get; set; }

		/// <summary>
		/// 注：关于图形元素中更多的样式设置（例如 富文本标签），参见 zrender/graphic/Displayable 中的 style 相关属性。
		/// 注意，这里图形元素的样式属性名称直接源于 zrender，和 echarts label、echarts itemStyle 等处同样含义的样式属性名称或有不同。例如，有如下对应：
		/// 
		/// itemStyle.color => style.fill
		/// itemStyle.borderColor => style.stroke
		/// label.color => style.textFill
		/// label.textBorderColor => style.textStroke
		/// ...
		/// </summary>
		[JsonProperty("style")]
		public SeriesCustomRenderItemReturnPathStyle Style { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在高亮图形时，是否淡出其它数据的图形已达到聚焦的效果。支持如下配置：
		/// 
		/// 'none' 不淡出其它图形，默认使用该配置。
		/// 'self' 只聚焦（不淡出）当前高亮的数据的图形。
		/// 'series' 聚焦当前高亮的数据所在的系列的所有图形。
		/// </summary>
		[JsonProperty("focus")]
		public string Focus { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 在开启focus的时候，可以通过blurScope配置淡出的范围。支持如下配置
		/// 
		/// 'coordinateSystem' 淡出范围为坐标系，默认使用该配置。
		/// 'series' 淡出范围为系列。
		/// 'global' 淡出范围为全局。
		/// </summary>
		[JsonProperty("blurScope")]
		public string BlurScope { get; set; }

		/// <summary>
		/// 是否关闭高亮状态。
		/// </summary>
		[JsonProperty("emphasisDisabled")]
		public bool? EmphasisDisabled { get; set; }

		/// <summary>
		/// 图形元素的高亮状态
		/// </summary>
		[JsonProperty("emphasis")]
		public SeriesCustomRenderItemReturnPathEmphasis Emphasis { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的淡出状态，配置focus时有效。
		/// </summary>
		[JsonProperty("blur")]
		public SeriesCustomRenderItemReturnPathBlur Blur { get; set; }

		/// <summary>
		/// 从 v5.0.0 开始支持
		/// 
		/// 图形元素的选中状态，配置自定义系列的 selectedMode 时有效。
		/// </summary>
		[JsonProperty("select")]
		public SeriesCustomRenderItemReturnPathSelect Select { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathSelect
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathBlur
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathEmphasis
	{
		/// <summary>
		/// 结构同 style。
		/// </summary>
		[JsonProperty("style")]
		public object Style { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathStyle
	{
		/// <summary>
		/// 填充色。
		/// </summary>
		[JsonProperty("fill")]
		public string Fill { get; set; }

		/// <summary>
		/// 线条颜色。
		/// </summary>
		[JsonProperty("stroke")]
		public string Stroke { get; set; }

		/// <summary>
		/// 线条宽度。
		/// </summary>
		[JsonProperty("lineWidth")]
		public double? LineWidth { get; set; }

		/// <summary>
		/// 线条样式。可选：
		/// 
		/// 'solid'
		/// 'dashed'
		/// 'dotted'
		/// number 或 number 数组。详见 MDN。
		/// </summary>
		[JsonProperty("lineDash")]
		public StringOrNumber[] LineDash { get; set; }

		/// <summary>
		/// 用于设置虚线的偏移量。详见 MDN。
		/// </summary>
		[JsonProperty("lineDashOffset")]
		public double? LineDashOffset { get; set; }

		/// <summary>
		/// 用于指定线段末端的绘制方式。详见 MDN。
		/// </summary>
		[JsonProperty("lineCap")]
		public string LineCap { get; set; }

		/// <summary>
		/// 设置线条转折点的样式。详见 MDN。
		/// </summary>
		[JsonProperty("lineJoin")]
		public string LineJoin { get; set; }

		/// <summary>
		/// 设置斜接面限制比例的属性。详见 MDN。
		/// </summary>
		[JsonProperty("miterLimit")]
		public double? MiterLimit { get; set; }

		/// <summary>
		/// 阴影宽度。
		/// </summary>
		[JsonProperty("shadowBlur")]
		public double? ShadowBlur { get; set; }

		/// <summary>
		/// 阴影 X 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetX")]
		public double? ShadowOffsetX { get; set; }

		/// <summary>
		/// 阴影 Y 方向偏移。
		/// </summary>
		[JsonProperty("shadowOffsetY")]
		public double? ShadowOffsetY { get; set; }

		/// <summary>
		/// 阴影颜色。
		/// </summary>
		[JsonProperty("shadowColor")]
		public double? ShadowColor { get; set; }

		/// <summary>
		/// 不透明度。
		/// </summary>
		[JsonProperty("opacity")]
		public double? Opacity { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 style 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     style: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 style 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     style: { ... },
		///     // `style` 下所有属性开启过渡动画。
		///     transition: 'style',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathShape
	{
		/// <summary>
		/// 即 SVG PathData。
		/// 例如：'M0,0 L0,-20 L30,-20 C42,-20 38,-1 50,-1 L70,-1 L70,0 Z'。
		/// 如果指定了 width、height、x、y，则会根据他们定义的矩形，缩放 PathData。如果没有指定这些，就不会缩放。
		/// 可使用 layout 指定缩放策略。
		/// 参见例子：
		/// icons 和 shapes。
		/// </summary>
		[JsonProperty("pathData")]
		public string PathData { get; set; }

		/// <summary>
		/// 同 pathData，别名。
		/// </summary>
		[JsonProperty("d")]
		public string D { get; set; }

		/// <summary>
		/// 如果指定了 width、height、x、y，则会根据他们定义的矩形，缩放 PathData。
		/// layout 用于指定缩放策略。
		/// 可选值：
		/// 
		/// 'center'：保持原来的 PathData 的长宽比，居于矩形中，尽可能撑大但不会超出矩形。
		/// 'cover'：PathData 拉伸为矩形的长宽比，完全填满矩形，不会超出矩形。
		/// </summary>
		[JsonProperty("layout")]
		public string Layout { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的横坐标值。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 图形元素的左上角在父节点坐标系（以父节点左上角为原点）中的纵坐标值。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 图形元素的宽度。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 图形元素的高度。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 shape 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     shape: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 shape 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     shape: { ... },
		///     // `shape` 下所有属性开启过渡动画。
		///     transition: 'shape',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnPathEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroup
	{
		/// <summary>
		/// 用 setOption 首次设定图形元素时必须指定。
		/// 可取值：
		/// image,
		/// text,
		/// circle,
		/// sector,
		/// ring,
		/// polygon,
		/// polyline,
		/// rect,
		/// line,
		/// bezierCurve,
		/// arc,
		/// group,
		/// </summary>
		[JsonProperty("type")]
		public string Type { get; set; }

		/// <summary>
		/// id 用于在更新或删除图形元素时指定更新哪个图形元素，如果不需要用可以忽略。
		/// </summary>
		[JsonProperty("id")]
		public string Id { get; set; }

		/// <summary>
		/// 元素的 x 像素位置。
		/// </summary>
		[JsonProperty("x")]
		public double? X { get; set; }

		/// <summary>
		/// 元素的 y 像素位置。
		/// </summary>
		[JsonProperty("y")]
		public double? Y { get; set; }

		/// <summary>
		/// 元素的旋转
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// 元素在 x 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleX")]
		public double? ScaleX { get; set; }

		/// <summary>
		/// 元素在 y 方向上的缩放。
		/// </summary>
		[JsonProperty("scaleY")]
		public double? ScaleY { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 x 像素位置。
		/// </summary>
		[JsonProperty("originX")]
		public double? OriginX { get; set; }

		/// <summary>
		/// 元素旋转和缩放原点的 y 像素位置。
		/// </summary>
		[JsonProperty("originY")]
		public double? OriginY { get; set; }

		/// <summary>
		/// 可以通过'all'指定所有属性都开启过渡动画，也可以指定单个或一组属性。
		/// Transform 相关的属性：'x'、 'y'、'scaleX'、'scaleY'、'rotation'、'originX'、'originY'。例如：
		/// {
		///     type: 'rect',
		///     x: 100,
		///     y: 200,
		///     transition: ['x', 'y']
		/// }
		/// 
		/// 还可以是这三个属性 'shape'、'style'、'extra'。表示这三个属性中所有的子属性都开启过渡动画。例如：
		/// {
		///     type: 'rect',
		///     shape: { // ... },
		///     // 表示 shape 中所有属性都开启过渡动画。
		///     transition: 'shape',
		/// }
		/// 
		/// 在自定义系列中，当 transition 没有指定时，'x' 和 'y' 会默认开启过渡动画。如果想禁用这种默认，可设定为空数组：transition: []
		/// transition 效果参考 例子。
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }

		/// <summary>
		/// 配置图形的入场属性用于入场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     enterFrom: {
		///         // 淡入
		///         style: { opacity: 0 },
		///         // 从左飞入
		///         x: 0
		///     }
		/// }
		/// </summary>
		[JsonProperty("enterFrom")]
		public object EnterFrom { get; set; }

		/// <summary>
		/// 配置图形的退场属性用于退场动画。例如：
		/// {
		///     type: 'circle',
		///     x: 100,
		///     leaveTo: {
		///         // 淡出
		///         style: { opacity: 0 },
		///         // 向右飞出
		///         x: 200
		///     }
		/// }
		/// </summary>
		[JsonProperty("leaveTo")]
		public object LeaveTo { get; set; }

		/// <summary>
		/// 入场动画配置。
		/// </summary>
		[JsonProperty("enterAnimation")]
		public SeriesCustomRenderItemReturnGroupEnterAnimation EnterAnimation { get; set; }

		/// <summary>
		/// 更新属性的动画配置。
		/// </summary>
		[JsonProperty("updateAnimation")]
		public SeriesCustomRenderItemReturnGroupUpdateAnimation UpdateAnimation { get; set; }

		/// <summary>
		/// 退场动画配置。
		/// </summary>
		[JsonProperty("leaveAnimation")]
		public SeriesCustomRenderItemReturnGroupLeaveAnimation LeaveAnimation { get; set; }

		/// <summary>
		/// 关键帧动画配置。支持配置为数组同时使用多个关键帧动画。
		/// 示例：
		/// keyframeAnimation: [{
		///     // 呼吸效果的缩放动画
		///     duration: 1000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0.5,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 0.1,
		///         scaleY: 0.1
		///     }, {
		///         percent: 1,
		///         easing: 'sinusoidalInOut',
		///         scaleX: 1,
		///         scaleY: 1
		///     }]
		/// }, {
		///     // 平移动画
		///     duration: 2000,
		///     loop: true,
		///     keyframes: [{
		///         percent: 0,
		///         x: 10
		///     }, {
		///         percent: 1,
		///         x: 100
		///     }]
		/// }]
		/// 
		/// 
		/// 假如一个属性同时被应用了关键帧动画和过渡动画，过渡动画会被忽略。
		/// </summary>
		[JsonProperty("keyframeAnimation")]
		public SeriesCustomRenderItemReturnGroupKeyframeAnimation KeyframeAnimation { get; set; }

		/// <summary>
		/// 用于决定图形元素的覆盖关系。
		/// </summary>
		[JsonProperty("z2")]
		public double? Z2 { get; set; }

		/// <summary>
		/// 参见 diffChildrenByName。
		/// </summary>
		[JsonProperty("name")]
		public string Name { get; set; }

		/// <summary>
		/// 用户定义的任意数据，可以在 event listener 中访问，如：
		/// chart.on('click', function (params) {
		///     console.log(params.info);
		/// });
		/// </summary>
		[JsonProperty("info")]
		public string Info { get; set; }

		/// <summary>
		/// 是否不响应鼠标以及触摸事件。
		/// </summary>
		[JsonProperty("silent")]
		public bool? Silent { get; set; }

		/// <summary>
		/// 节点是否完全被忽略（既不渲染，也不响应事件）。
		/// </summary>
		[JsonProperty("ignore")]
		public bool? Ignore { get; set; }

		/// <summary>
		/// 这是一个文本定义，附着在一个节点上，会依据 textConfig 配置，相对于节点布局。
		/// 里面的属性同于 text。
		/// </summary>
		[JsonProperty("textContent")]
		public object TextContent { get; set; }

		/// <summary>
		///SeriesCustom_RenderItem_Return_Group_TextConfig
		/// </summary>
		[JsonProperty("textConfig")]
		public SeriesCustomRenderItemReturnGroupTextConfig TextConfig { get; set; }

		/// <summary>
		/// 在动画的每一帧里，用户可以使用 during 回调来设定节点的各种属性。
		/// (duringAPI: CustomDuringAPI) => void
		/// 
		/// interface CustomDuringAPI {
		///     // 设置 transform 属性值。
		///     // transform 属性参见 `TransformProp`。
		///     setTransform(key: TransformProp, val: unknown): void;
		///     // 获得当前动画帧的 transform 属性值。
		///     getTransform(key: TransformProp): unknown;
		///     // 设置 shape 属性值。
		///     // shape 属性形如：`{ type: 'rect', shape: { xxxProp: xxxValue } }`。
		///     setShape(key: string, val: unknown): void;
		///     // 获得当前动画帧的 shape 属性值。
		///     getShape(key: string): unknown;
		///     // 设置 style 属性值。
		///     // style 属性形如：`{ type: 'rect', style: { xxxProp: xxxValue } }`。
		///     setStyle(key: string, val: unknown): void;
		///     // 获得当前动画帧的 style 属性值。
		///     getStyle(key: string): unknown;
		///     // 设置 extra 属性值。
		///     // extra 属性形如：`{ type: 'rect', extra: { xxxProp: xxxValue } }`。
		///     setExtra(key: string, val: unknown): void;
		///     // 获得当前动画帧的 extra 属性值。
		///     getExtra(key: string): unknown;
		/// }
		/// 
		/// type TransformProp =
		///     'x' | 'y' | 'scaleX' | 'scaleY' | 'originX' | 'originY' | 'rotation';
		/// 
		/// 在绝大多数场景下，用户不需要这个 during 回调。因为，假如属性被设定到 transition 中后，echarts 会自动对它进行插值，并且基于这些插值形成动画。但是，如果这些插值形成的动画不满足用户需求，那么用户可以使用 during 回调来定制他们。
		/// 例如，如果用户使用 polygon 画图形，图形的形状会由 shape.points 来定义，形如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...]
		///     },
		///     // ...
		/// }
		/// 
		/// 如果用户指定了 transition 如：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: [[12, 33], [15, 36], [19, 39], ...],
		///     },
		///     transition: 'shape'
		///     // ...
		/// }
		/// 
		/// 尽管这些 points 会被 echarts 自动插值，但是这样形成的动画里，这些点会直线走向目标位置。假如用户需求是，这些点要按照某种特定的路径（如弧线、螺旋）来移动，则这就不满足了。所以在这种情况下，可以使用 during 回调如下：
		/// {
		///     type: 'polygon',
		///     shape: {
		///         points: calculatePoints(initialDegree),
		///         transition: 'points'
		///     },
		///     extra: {
		///         degree: nextDegree
		///     },
		///     // 让 echarts 对 `extra.degree` 进行插值，然后基于
		///     // `extra.degree` 来计算动画中每一帧时的 polygon 形状。
		///     transition: 'extra',
		///     during: function (duringAPI) {
		///         var currentDegree = duringAPI.getExtra('degree');
		///         duringAPI.setShape(calculatePoints(currentDegree));
		///     }
		///     // ...
		/// }
		/// 
		/// 也参见这个 例子。
		/// </summary>
		[JsonProperty("during")]
		public string During { get; set; }

		/// <summary>
		/// 用户可以在 extra 字段中定义自己的属性。extra 的往往会结合 during 一起使用。
		/// </summary>
		[JsonProperty("extra")]
		public SeriesCustomRenderItemReturnGroupExtra Extra { get; set; }

		/// <summary>
		/// 用于描述此 group 的宽。
		/// 这个宽只用于给子节点定位。
		/// 即便当宽度为零的时候，子节点也可以使用 left: 'center' 相对于父节点水平居中。
		/// </summary>
		[JsonProperty("width")]
		public double? Width { get; set; }

		/// <summary>
		/// 用于描述此 group 的高。
		/// 这个高只用于给子节点定位。
		/// 即便当高度为零的时候，子节点也可以使用 top: 'middle' 相对于父节点垂直居中。
		/// </summary>
		[JsonProperty("height")]
		public double? Height { get; set; }

		/// <summary>
		/// 在 自定义系列 中，当 diffChildrenByName: true 时，对于 renderItem 返回值中的每一个 group，会根据其 children 中每个图形元素的 name 属性进行 "diff"。在这里，"diff" 的意思是，重绘的时候，在已存在的图形元素和新的图形元素之间建立对应关系（依据 name 是否相同），从如果数据有更新，能够形成的过渡动画。
		/// 但是注意，这会有性能开销。如果数据量较大，不要开启这个功能。
		/// </summary>
		[JsonProperty("diffChildrenByName")]
		public bool? DiffChildrenByName { get; set; }

		/// <summary>
		/// 子节点列表，其中项都是一个图形元素定义。
		/// </summary>
		[JsonProperty("children")]
		public double[] Children { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupExtra
	{
		/// <summary>
		/// 可以是一个属性名，或者一组属性名。
		/// 被指定的属性，在其指发生变化时，会开启过渡动画。
		/// 只可以指定本 extra 下的属性。
		/// 例如：
		/// {
		///     type: 'rect',
		///     extra: {
		///         // ...
		///         // 这两个属性会开启过渡动画。
		///         transition: ['mmm', 'ppp']
		///     }
		/// }
		/// 
		/// 我们这样可以指定 extra 下所有属性开启过渡动画：
		/// {
		///     type: 'rect',
		///     extra: { ... },
		///     // `extra` 下所有属性开启过渡动画。
		///     transition: 'extra',
		/// }
		/// </summary>
		[JsonProperty("transition")]
		public string[] Transition { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupTextConfig
	{
		/// <summary>
		/// Position of textContent.
		/// 
		/// 'left'
		/// 'right'
		/// 'top'
		/// 'bottom'
		/// 'inside'
		/// 'insideLeft'
		/// 'insideRight'
		/// 'insideTop'
		/// 'insideBottom'
		/// 'insideTopLeft'
		/// 'insideTopRight'
		/// 'insideBottomLeft'
		/// 'insideBottomRight'
		/// or like [12, 33]
		/// or like ['50%', '50%']
		/// </summary>
		[JsonProperty("position")]
		public string Position { get; set; }

		/// <summary>
		/// textContent 的旋转弧度。
		/// </summary>
		[JsonProperty("rotation")]
		public double? Rotation { get; set; }

		/// <summary>
		/// textContent 根据此矩形来布局位置。
		/// 默认是节点的包围盒。
		/// {
		///     x: number
		///     y: number
		///     width: number
		///     height: number
		/// }
		/// </summary>
		[JsonProperty("layoutRect")]
		public object LayoutRect { get; set; }

		/// <summary>
		/// textContent 的偏移。
		/// offset 和 position 的区别是，offset 是旋转（rotation）后计算。
		/// </summary>
		[JsonProperty("offset")]
		public double[] Offset { get; set; }

		/// <summary>
		/// origin 相对于节点的包围盒。
		/// 可以是百分数。
		/// 如果指定为 'center'，则定位在包围盒中心。
		/// 只有当 position and rotation 都设置时，生效。
		/// 
		/// 如 [12, 33]
		/// 或如 ['50%', '50%']
		/// 'center'
		/// </summary>
		[JsonProperty("origin")]
		public string Origin { get; set; }

		/// <summary>
		/// 距离 layoutRect 的距离。
		/// </summary>
		[JsonProperty("distance")]
		public double? Distance { get; set; }

		/// <summary>
		/// 如果 true 的话，会采用节点的 transform。
		/// </summary>
		[JsonProperty("local")]
		public bool? Local { get; set; }

		/// <summary>
		/// insideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.insideFill > "auto-calculated-fill"
		/// 在绝大多数场景下，"auto-calculated-fill" 是白色。
		/// </summary>
		[JsonProperty("insideFill")]
		public string InsideFill { get; set; }

		/// <summary>
		/// insideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.insideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会和节点的 fill 相同，如果 fill 没有的话则为 null。
		/// </summary>
		[JsonProperty("insideStroke")]
		public string InsideStroke { get; set; }

		/// <summary>
		/// outsideFill 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 是 "inside"，它的 fill 会按这个优先级来选取：
		/// textContent.style.fill > textConfig.outsideFill > #000
		/// </summary>
		[JsonProperty("outsideFill")]
		public string OutsideFill { get; set; }

		/// <summary>
		/// outsideStroke 可以是一个颜色字符串，或者空着。
		/// 如果 textContent 不是 "inside"，它的 stroke 会按这个优先级来选取：
		/// textContent.style.stroke > textConfig.outsideStroke > "auto-calculated-stroke"
		/// "auto-calculated-stroke" 的规则是：
		/// 
		/// 如果
		/// (A) fill 在 style 中被指定（无论是在 textContent.style 还是 textContent.style.rich 里）
		/// 或者 (B) 需要画文字的背景（无论是定义在 textContent.style 还是 textContent.style.rich 里）
		/// "auto-calculated-stroke" 都会为 null。
		/// 
		/// 
		/// 否则
		/// "auto-calculated-stroke" 会为一个近似于白色的颜色，来区别于背景。
		/// </summary>
		[JsonProperty("outsideStroke")]
		public string OutsideStroke { get; set; }

		/// <summary>
		/// 如果确定文本是在节点中的话，则此可设置为 true，避免 echarts 额外猜测。
		/// </summary>
		[JsonProperty("inside")]
		public bool? Inside { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupKeyframeAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }

		/// <summary>
		/// 是否循环播放动画。
		/// </summary>
		[JsonProperty("loop")]
		public bool? Loop { get; set; }

		/// <summary>
		/// 动画的关键帧。数组中每一项为一个关键帧，格式如下：
		/// interface Keyframe {
		///     // 关键帧位置。0 为第一帧，1 为最后一帧
		///     // 关键帧时间为 percent * duration + delay
		///     percent: number
		///     // 上一个关键帧到这个关键帧运行时的缓动函数。可选
		///     easing?: number
		/// 
		///     // 其它属性为图形在这个关键帧的属性，例如 x, y, style, shape 等
		/// }
		/// </summary>
		[JsonProperty("keyframes")]
		public double[] Keyframes { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupLeaveAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupUpdateAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemReturnGroupEnterAnimation
	{
		/// <summary>
		/// 动画时长，单位 ms
		/// </summary>
		[JsonProperty("duration")]
		public double? Duration { get; set; }

		/// <summary>
		/// 动画缓动。不同的缓动效果可以参考 缓动示例。
		/// </summary>
		[JsonProperty("easing")]
		public string Easing { get; set; }

		/// <summary>
		/// 动画延迟时长，单位 ms
		/// </summary>
		[JsonProperty("delay")]
		public double? Delay { get; set; }
	}

	public class SeriesCustomRenderItemArguments
	{
		/// <summary>
		/// renderItem 函数的第一个参数，含有：
		/// {
		///     context: // {Object} 一个可供开发者暂存东西的对象。生命周期只为：当前次的渲染。
		///     seriesId: // {string} 本系列 id。
		///     seriesName: // {string} 本系列 name。
		///     seriesIndex: // {number} 本系列 index。
		///     dataIndex: // {number} 数据项的 index。
		///     dataIndexInside: // {number} 数据项在当前坐标系中可见的数据的 index（即 dataZoom 当前窗口中的数据的 index）。
		///     dataInsideLength: // {number} 当前坐标系中可见的数据长度（即 dataZoom 当前窗口中的数据数量）。
		///     actionType: // {string} 触发此次重绘的 action 的 type。
		///     coordSys: // 不同的坐标系中，coordSys 里的信息不一样，含有如下这些可能：
		///     coordSys: {
		///         type: 'cartesian2d',
		///         x: // {number} grid rect 的 x
		///         y: // {number} grid rect 的 y
		///         width: // {number} grid rect 的 width
		///         height: // {number} grid rect 的 height
		///     },
		///     coordSys: {
		///         type: 'calendar',
		///         x: // {number} calendar rect 的 x
		///         y: // {number} calendar rect 的 y
		///         width: // {number} calendar rect 的 width
		///         height: // {number} calendar rect 的 height
		///         cellWidth: // {number} calendar cellWidth
		///         cellHeight: // {number} calendar cellHeight
		///         rangeInfo: {
		///             start: // calendar 日期开端
		///             end: // calendar 日期结尾
		///             weeks: // calendar 周数
		///             dayCount: // calendar 日数
		///         }
		///     },
		///     coordSys: {
		///         type: 'geo',
		///         x: // {number} geo rect 的 x
		///         y: // {number} geo rect 的 y
		///         width: // {number} geo rect 的 width
		///         height: // {number} geo rect 的 height
		///         zoom: // {number} 缩放的比率。如果没有缩放，则值为 1。例如 0.5 表示缩小了一半。
		///     },
		///     coordSys: {
		///         type: 'polar',
		///         cx: // {number} polar 的中心坐标
		///         cy: // {number} polar 的中心坐标
		///         r: // {number} polar 的外半径
		///         r0: // {number} polar 的内半径
		///     },
		///     coordSys: {
		///         type: 'singleAxis',
		///         x: // {number} singleAxis rect 的 x
		///         y: // {number} singleAxis rect 的 y
		///         width: // {number} singleAxis rect 的 width
		///         height: // {number} singleAxis rect 的 height
		///     }
		/// }
		/// 
		/// 其中，关于 dataIndex 和 dataIndexInside 的区别：
		/// 
		/// dataIndex 指的 dataItem 在原始数据中的 index。
		/// dataIndexInside 指的是 dataItem 在当前数据窗口（参见 dataZoom）中的 index。
		/// 
		/// renderItem.arguments.api 中使用的参数都是 dataIndexInside 而非 dataIndex，因为从 dataIndex 转换成 dataIndexInside 需要时间开销。
		/// </summary>
		[JsonProperty("params")]
		public object Params { get; set; }

		/// <summary>
		/// renderItem 函数的第二个参数。
		/// </summary>
		[JsonProperty("api")]
		public SeriesCustomRenderItemArgumentsApi Api { get; set; }
	}

	public class SeriesCustomRenderItemArgumentsApi
	{
		/// <summary>
		/// 得到给定维度的数据值。
		/// @param {number} dimension 指定的维度（维度从 0 开始计数）。
		/// @param {number} [dataIndexInside] 一般不用传，默认就是当前数据项的 dataIndexInside。
		/// @return {number} 给定维度上的值。
		/// </summary>
		[JsonProperty("value")]
		public string Value { get; set; }

		/// <summary>
		/// 将数据值映射到坐标系上。
		/// @param {Array.<number>} data 数据值。
		/// @return {Array.<number>} 画布上的点的坐标，至少包含：[x, y]
		///         对于polar坐标系，还会包含其他信息：
		///         polar: [x, y, radius, angle]
		/// </summary>
		[JsonProperty("coord")]
		public string Coord { get; set; }

		/// <summary>
		/// 给定数据范围，映射到坐标系上后的长度。
		/// 例如，cartesian2d中，api.size([2, 4]) 返回 [12.4, 55]，表示 x 轴数据范围为 2 映射得到长度是 12.4，y 轴数据范围为 4 时应设得到长度为 55。
		/// 在一些坐标系中，如极坐标系（polar）或者有 log 数轴的坐标系，不同点的长度是不同的，所以需要第二个参数，指定获取长度的点。
		/// @param {Array.<number>} dataSize 数据范围。
		/// @param {Array.<number>} dataItem 获取长度的点。
		/// @return {Array.<number>} 画布上的长度
		/// </summary>
		[JsonProperty("size")]
		public string Size { get; set; }

		/// <summary>
		/// 能得到 series.itemStyle 中定义的样式信息和视觉映射得到的样式信息，可直接用于绘制图元。也可以用这种方式覆盖这些样式信息：api.style({fill: 'green', stroke: 'yellow'})。
		/// @param {Object} [extra] 额外指定的样式信息。
		/// @param {number} [dataIndexInside] 一般不用传，默认就是当前数据项的 dataIndexInside。
		/// @return {Object} 直接用于绘制图元的样式信息。
		/// </summary>
		[JsonProperty("style")]
		public string Style { get; set; }

		/// <summary>
		/// 能得到 series.itemStyle.emphasis 中定义的样式信息和视觉映射的样式信息，可直接用于绘制图元。也可以用这种方式覆盖这些样式信息：api.style({fill: 'green', stroke: 'yellow'})。
		/// @param {Object} [extra] 额外指定的样式信息。
		/// @param {number} [dataIndexInside] 一般不用传，默认就是当前数据项的 dataIndexInside。
		/// @return {Object} 直接用于绘制图元的样式信息。
		/// </summary>
		[JsonProperty("styleEmphasis")]
		public string StyleEmphasis { get; set; }

		/// <summary>
		/// 得到视觉映射的样式信息。比较少被使用。
		/// @param {string} visualType 'color', 'symbol', 'symbolSize', ...
		/// @param {number} [dataIndexInside] 一般不用传，默认就是当前数据项的 dataIndexInside。
		/// @return {string|number} 视觉映射的样式值。
		/// </summary>
		[JsonProperty("visual")]
		public string Visual { get; set; }

		/// <summary>
		/// 当需要采用 barLayout 的时候，比如向柱状图上附加些东西，可以用这个方法得到 layout 信息。
		/// 参见 例子。
		/// @param {Object} opt
		/// @param {number} opt.count 每个簇有多少个 bar。
		/// @param {number|string} [opt.barWidth] bar 宽度。
		///         可以是绝对值例如 `40` 或者百分数例如 `'60%'`。
		///         百分数基于自动计算出的每一类目的宽度。
		/// @param {number|string} [opt.barMaxWidth] bar 最大宽度。
		///         可以是绝对值例如 `40` 或者百分数例如 `'60%'`。
		///         百分数基于自动计算出的每一类目的宽度。
		///         比 `opt.barWidth` 优先级高。
		/// @param {number|string} [opt.barMinWidth] bar 最小宽度。
		///         可以是绝对值例如 `40` 或者百分数例如 `'60%'`。
		///         百分数基于自动计算出的每一类目的宽度。
		///         比 `opt.barWidth` 优先级高。
		/// @param {number} [opt.barGap] 每个簇的 bar 之间的宽度。
		/// @param {number} [opt.barCategoryGap] 不同簇间的宽度。
		/// @return {Array.<Object>} [{
		///         width: number bar 的宽度。
		///         offset: number bar 的偏移量，以bar最左为基准。
		///         offsetCenter: number bar 的偏移量，以bar中心为基准。
		///     }, ...]
		/// </summary>
		[JsonProperty("barLayout")]
		public string BarLayout { get; set; }

		/// <summary>
		/// 得到系列的 当前index。注意这个 index 不同于系列定义时的 index。这个 index 是当 legend 组件进行了系列筛选后，剩余的系列排列后的 index。
		/// @return {number}
		/// </summary>
		[JsonProperty("currentSeriesIndices")]
		public string CurrentSeriesIndices { get; set; }

		/// <summary>
		/// 得到可以直接进行样式设置的文字信息字符串。
		/// @param {Object} opt
		/// @param {string} [opt.fontStyle]
		/// @param {number} [opt.fontWeight]
		/// @param {number} [opt.fontSize]
		/// @param {string} [opt.fontFamily]
		/// @return {string} font 字符串。
		/// </summary>
		[JsonProperty("font")]
		public string Font { get; set; }

		/// <summary>
		/// @return {number} echarts 容器的宽度。
		/// </summary>
		[JsonProperty("getWidth")]
		public string GetWidth { get; set; }

		/// <summary>
		/// @return {number} echarts 容器的高度。
		/// </summary>
		[JsonProperty("getHeight")]
		public string GetHeight { get; set; }

		/// <summary>
		/// @return {module:zrender} zrender 实例。
		/// </summary>
		[JsonProperty("getZr")]
		public string GetZr { get; set; }

		/// <summary>
		/// @return {number} 得到当前 devicePixelRatio。
		/// </summary>
		[JsonProperty("getDevicePixelRatio")]
		public string GetDevicePixelRatio { get; set; }
	}
}