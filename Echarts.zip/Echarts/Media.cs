using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Echarts
{
        /// <summary>
        /// 请参见 移动端自适应。
        /// </summary>
    public class Query
    {
        /// <summary>
        ///Query_MinWidth
        /// </summary>
        [JsonProperty("minWidth")]
        public Query_MinWidth MinWidth { get; set; }

        /// <summary>
        ///Query_MaxHeight
        /// </summary>
        [JsonProperty("maxHeight")]
        public Query_MaxHeight MaxHeight { get; set; }

        /// <summary>
        ///Query_MinAspectRatio
        /// </summary>
        [JsonProperty("minAspectRatio")]
        public Query_MinAspectRatio MinAspectRatio { get; set; }

    }
    }
